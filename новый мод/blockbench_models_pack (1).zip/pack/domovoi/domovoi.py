import sys, math, json
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge, wave, hover
import pixelart as px
W,FR=128,8
tex=Texture(W,W,FR,name="domovoi",frame_time=3)
for k,r in {"fur":(0,0,32,64),"dfur":(32,0,64,64),"shirt":(64,0,96,32),"skin":(96,0,128,32),"beard":(64,32,96,64),"bast":(96,32,128,64),"face":(0,64,32,96),"shirt_front":(32,64,64,96),"straw":(64,64,96,96),"wood":(96,64,128,96),"eye":(0,96,32,128),"pants":(32,96,64,128),"bread":(64,96,96,128),"ember":(96,96,128,128)}.items(): tex.region(k,*r)
base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda k,im: base.paste(im,tex.regions[k][:2])
fu=px.noise_tile(32,64,(110,78,48),var=18,bevel=False,seed=1); d=ImageDraw.Draw(fu)
for _ in range(220): x,y=px.random.randint(0,30),px.random.randint(0,60); d.line([x,y,x+px.random.randint(-1,1),y+3],fill=(80,54,30,255))
for _ in range(120): x,y=px.random.randint(0,30),px.random.randint(0,60); d.line([x,y,x,y+2],fill=(150,110,70,255))
put("fur",fu); put("dfur",px.noise_tile(32,64,(72,50,30),var=14,bevel=False,seed=2)); df2=base.crop((32,0,64,64)); dd=ImageDraw.Draw(df2)
for _ in range(180): x,y=px.random.randint(0,30),px.random.randint(0,60); dd.line([x,y,x,y+3],fill=(50,34,20,255))
put("dfur",df2)
sh=px.noise_tile(32,32,(196,60,48),var=14,bands=True,seed=3); dsh=ImageDraw.Draw(sh)
for y in range(2,32,6): dsh.line([0,y,31,y],fill=(240,200,80,255)); dsh.line([0,y+2,31,y+2],fill=(150,40,32,255))
put("shirt",sh); put("skin",px.noise_tile(32,32,(214,168,130),var=14,seed=4))
bd=px.noise_tile(32,32,(224,222,214),var=12,bevel=False,seed=5); dbd=ImageDraw.Draw(bd)
for x in range(0,32,2): dbd.line([x,0,x+px.random.randint(-2,2),31],fill=(190,186,176,255))
for _ in range(20): x,y=px.random.randint(0,30),px.random.randint(0,30); dbd.line([x,y,x,y+2],fill=(160,150,140,255))
put("beard",bd)
ba=px.noise_tile(32,32,(190,150,80),var=12,bevel=False,seed=6); dba=ImageDraw.Draw(ba)
for i in range(0,32,4): dba.line([i,0,31,31-i],fill=(140,105,50,255)); dba.line([0,i,31-i,31],fill=(140,105,50,255)); dba.line([i,31,31,i],fill=(220,185,110,255))
put("bast",ba)
st=px.noise_tile(32,32,(210,170,80),var=20,bevel=False,seed=7); dst=ImageDraw.Draw(st)
for x in range(0,32,2): dst.line([x,0,x+px.random.randint(-1,1),31],fill=(170,130,50,255))
put("straw",st); w=px.noise_tile(32,32,(120,84,46),var=14,bands=True,layers_freq=.3,seed=8); put("wood",w)
put("pants",px.noise_tile(32,32,(60,70,110),var=12,bands=True,seed=9)); pa=base.crop((32,96,64,128)); dpa=ImageDraw.Draw(pa)
for y in range(0,32,3): dpa.line([0,y,31,y],fill=(45,52,90,255))
dpa.rectangle([8,10,16,18],fill=(110,80,50,255)); dpa.rectangle([8,10,16,18],outline=(70,50,30,255)); put("pants",pa)
br=px.noise_tile(32,32,(170,110,50),var=16,bevel=False,seed=10); dbr=ImageDraw.Draw(br); dbr.ellipse([2,6,29,26],fill=(190,130,60,255)); dbr.ellipse([4,8,27,24],outline=(220,170,90,255)); dbr.arc([6,10,25,22],200,340,fill=(120,70,30,255)); put("bread",br)
f=px.noise_tile(32,32,(110,78,48),var=18,bevel=False,seed=11); dfc=ImageDraw.Draw(f)
for _ in range(120): x,y=px.random.randint(0,30),px.random.randint(0,30); dfc.line([x,y,x,y+3],fill=(80,54,30,255))
dfc.rectangle([6,12,26,22],fill=(214,168,130,255))                                   # skin patch
dfc.rectangle([4,8,13,11],fill=(224,222,214,255)); dfc.rectangle([19,8,28,11],fill=(224,222,214,255))   # bushy brows
dfc.ellipse([12,16,20,22],fill=(200,130,110,255)); dfc.point((14,17),fill=(230,180,160,255))          # round nose
dfc.rectangle([0,23,31,31],fill=(224,222,214,255)); 
for x in range(0,32,2): dfc.line([x,23,x+px.random.randint(-1,1),31],fill=(190,186,176,255))
dfc.rectangle([11,24,21,25],fill=(60,30,30,255))                                                        # mouth hidden in beard
put("face",f)
sf=sh.copy(); dsf=ImageDraw.Draw(sf); dsf.rectangle([12,0,19,12],fill=(240,220,180,255)); dsf.rectangle([13,1,18,11],fill=(214,168,130,255))
for y in range(0,12,3): dsf.rectangle([15,y+1,16,y+2],fill=(120,60,50,255))
dsf.rectangle([0,26,31,31],fill=(110,80,50,255)); dsf.rectangle([13,25,18,31],fill=(180,140,60,255)); put("shirt_front",sf)
put("eye",Image.new("RGBA",(32,32),(0,0,0,0))); put("ember",Image.new("RGBA",(32,32),(0,0,0,0)))
def paint(fr,fi,t):
    d=ImageDraw.Draw(fr); k=(math.sin(t)+1)/2; blink=(math.sin(t*1.5+2)>.93)
    ex,ey=tex.regions["eye"][:2]
    if blink: d.rectangle([ex+4,ey+12,ex+27,ey+19],fill=(110,78,48,255)); d.line([ex+4,ey+16,ex+27,ey+16],fill=(60,40,24,255),width=2)
    else:
        d.ellipse([ex+4,ey+6,ex+27,ey+26],fill=(255,240,200,255)); d.ellipse([ex+9+int(2*math.sin(t)),ey+10,ex+23+int(2*math.sin(t)),ey+24],fill=(int(230+25*k),int(140+60*k),30,255)); d.ellipse([ex+13+int(2*math.sin(t)),ey+13,ex+19+int(2*math.sin(t)),ey+21],fill=(20,10,5,255)); d.point((ex+14+int(2*math.sin(t)),ey+14),fill=(255,255,255,255))
    fx,fy=tex.regions["face"][:2]
    for cx in (9,23):
        if blink: d.line([fx+cx-2,fy+14,fx+cx+2,fy+14],fill=(60,40,24,255))
        else: d.ellipse([fx+cx-2,fy+12,fx+cx+2,fy+16],fill=(255,240,200,255)); d.point((fx+cx+int(math.sin(t)),fy+14),fill=(int(230+25*k),int(140+60*k),30,255)); d.point((fx+cx+int(math.sin(t)),fy+14),fill=(int(230+25*k),int(140+60*k),30,255))
    emx,emy=tex.regions["ember"][:2]
    for i in range(12):
        x=(i*7+3)%32; y=int((i*9-fi*1.5)%32); a=int(200*(.5+.5*math.sin(t+i)))
        d.point((emx+x,emy+y),fill=(255,int(150+80*k),60,a)); d.point((emx+x,emy+y+1),fill=(255,90,30,a//2))
    ffx,ffy=tex.regions["fur"][:2]
    for i in range(6): x=(i*11+2)%30; y=(i*17+fi*3)%60; fr.putpixel((ffx+x,ffy+y),(180,140,90,255))   # fur highlights ripple
strip=px.make_strip(base,FR,paint); tex.set_image(strip); strip.save("trio/domovoi.png"); json.dump(tex.mcmeta(),open("trio/domovoi.png.mcmeta","w"))

m=Model("domovoi",tex,fmt="free",seed=13)
m.bone("root",[0,0,0]); m.bone("body",[0,6,0],"root",rot=[-6,0,0]); m.bone("head",[0,13,0],"body",rot=[4,0,0]); m.bone("beard",[0,13,-5],"head"); m.bone("brows",[0,19,-5.5],"head"); m.bone("hair_top",[0,22,0],"head")
m.bone("arm_left",[5,12,0],"body",rot=[10,0,-15]); m.bone("arm_right",[-5,12,0],"body",rot=[30,0,15]); m.bone("broom",[-6,5,-3],"arm_right",rot=[0,0,10])
m.bone("leg_left",[2,6,0],"root"); m.bone("leg_right",[-2,6,0],"root"); m.bone("bread",[6,9,-4],"arm_left")
for i in range(4): m.bone(f"ember_{i}",[0,10,0],"root")
m.cube("belly",[-5,5,-3.5],[5,13,3.5],"shirt","body",faces={"north":"shirt_front"}); m.cube("belly_fur",[-5.4,5.5,-3.9],[5.4,7.5,3.9],"fur","body"); m.cube("belt",[-5.3,7,-3.8],[5.3,8.5,3.8],"bast","body")
m.cube("back_fur",[-4.5,8,3.4],[4.5,13,5],"fur","body"); m.cube("tail_fur",[-1,3,3],[1,6,5],"dfur","body",rot=[30,0,0],origin=[0,6,3.5])
m.cube("head",[-6,13,-6],[6,22,5],"fur","head",faces={"north":"face"}); m.cube("hair_top",[-6.5,21.5,-6.5],[6.5,24,5.5],"dfur","hair_top"); m.cube("hair_tuft",[-2,23.5,-3],[2,27,0],"dfur","hair_top",rot=[-20,0,15],origin=[0,23.5,-1.5]); m.cube("hair_tuft2",[1,23.5,-1],[4,26,2],"dfur","hair_top",rot=[10,0,-30],origin=[2.5,23.5,.5])
m.cube("ear_l",[-8.5,17,-2],[-6,21,1],"fur","head",rot=[0,0,20],origin=[-6,17,-.5]); m.cube("ear_r",[6,17,-2],[8.5,21,1],"fur","head",rot=[0,0,-20],origin=[6,17,-.5]); m.cube("ear_in_l",[-8,17.8,-1.5],[-6.4,20.2,.5],"skin","head",rot=[0,0,20],origin=[-6,17,-.5]); m.cube("ear_in_r",[6.4,17.8,-1.5],[8,20.2,.5],"skin","head",rot=[0,0,-20],origin=[6,17,-.5])
m.cube("nose",[-1.5,15.5,-7.4],[1.5,18,-5.8],"skin","head"); m.cube("eye_l",[-4.3,17.5,-6.5],[-1.6,19.5,-5.8],"eye","head",full=True); m.cube("eye_r",[1.6,17.5,-6.5],[4.3,19.5,-5.8],"eye","head",full=True)
m.cube("brow_l",[-5,19.3,-6.8],[-1.2,20.8,-5.6],"beard","brows",rot=[0,0,8]); m.cube("brow_r",[1.2,19.3,-6.8],[5,20.8,-5.6],"beard","brows",rot=[0,0,-8])
m.cube("beard",[-5,4,-7],[5,15.5,-4.5],"beard","beard",rot=[-4,0,0]); m.cube("beard_tip",[-2.5,0,-7.2],[2.5,5,-5],"beard","beard",rot=[-8,0,0]); m.cube("mustache_l",[-4.5,14.6,-7.6],[-.3,16,-6.6],"beard","head",rot=[0,0,-10],origin=[-.3,15.5,-7]); m.cube("mustache_r",[.3,14.6,-7.6],[4.5,16,-6.6],"beard","head",rot=[0,0,10],origin=[.3,15.5,-7])
m.cube("beard_side_l",[-6.4,9,-6],[-4.8,15,-3],"beard","beard"); m.cube("beard_side_r",[4.8,9,-6],[6.4,15,-3],"beard","beard")
for sgn,a in ((1,"arm_left"),(-1,"arm_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(5,8); m.cube(f"sleeve_{a}",[xa,7,-1.5],[xb,12.5,1.5],"shirt",a); xa,xb=X(4.8,8.2); m.cube(f"cuff_{a}",[xa,6.5,-1.8],[xb,7.5,1.8],"bast",a); xa,xb=X(5.2,7.8); m.cube(f"hand_{a}",[xa,4,-1.5],[xb,6.5,1.5],"fur",a)
    for i in range(3): xa,xb=X(5.3+i*.85,5.9+i*.85); m.cube(f"finger_{a}_{i}",[xa,2.2,-1.4],[xb,4.2,-.4],"skin",a,rot=[-15,0,0],origin=[(xa+xb)/2,4.2,-.9])
for sgn,lg in ((1,"leg_left"),(-1,"leg_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(.5,3.5); m.cube(f"leg_{lg}",[xa,2,-1.5],[xb,6.5,1.5],"pants",lg); xa,xb=X(.3,3.7); m.cube(f"wrap_{lg}",[xa,2.5,-1.8],[xb,4.5,1.8],"bast",lg); xa,xb=X(0,4); m.cube(f"lapot_{lg}",[xa,0,-3.5],[xb,2.2,1.5],"bast",lg,full=True); xa,xb=X(.5,3.5); m.cube(f"lapot_toe_{lg}",[xa,.5,-4.5],[xb,2.5,-3.4],"bast",lg,rot=[20,0,0],origin=[(xa+xb)/2,.5,-3.5])
m.cube("broom_stick",[-6.5,-1,-3.5],[-5.5,14,-2.5],"wood","broom"); m.cube("broom_bind",[-7.2,-1,-4.2],[-4.8,1,-1.8],"bast","broom"); m.cube("broom_head",[-8.5,-6,-5.5],[-3.5,-1,-.5],"straw","broom",full=True); m.cube("broom_tips",[-9,-8,-6],[-3,-5.5,0],"straw","broom",rot=[0,15,0],full=True)
m.cube("bread",[4.5,6.5,-6.5],[8.5,9.5,-2],"bread","bread",full=True,rot=[10,0,-15],origin=[6.5,8,-4])
for i in range(4):
    a=math.radians(i*90+45); x,z=math.cos(a)*7,math.sin(a)*6; y=6+i*3
    m.cube(f"ember_{i}",[x-.5,y-.5,z-.5],[x+.5,y+.5,z+.5],"ember",f"ember_{i}",full=True,rot=[45,45,0],origin=[x,y,z])
Z=[0,0,0]; L="linear"; embers=[f"ember_{i}" for i in range(4)]
def amb(length): return merge(wave("beard",length,3,1,.3),wave("hair_top",length,3,1,.7,axis=2),{b:{"position":[(length*k/8,[math.cos(2*math.pi*k/8+i*1.57)*1.5,((k/8)*8+i*2)%8-4,math.sin(2*math.pi*k/8+i*1.57)*1.5]) for k in range(9)]} for i,b in enumerate(embers)})
m.animation("idle",4,True,merge(amb(4),{"body":{"rotation":[(0,Z),(2,[-3,0,0]),(4,Z)],"position":[(0,Z),(2,[0,-.4,0]),(4,Z)]},"head":{"rotation":[(0,Z),(.9,[3,20,5]),(1.0,[3,22,6],L),(1.9,[0,18,4]),(2.0,[-4,-18,-5],L),(2.9,[-2,-15,-4]),(3.0,[0,0,0],L),(4,Z)]},
 "brows":{"rotation":[(0,Z),(.9,[-15,0,0]),(1.2,Z),(2.0,[10,0,0]),(2.4,Z),(4,Z)]},"arm_left":{"rotation":[(0,Z),(2,[5,0,-5]),(4,Z)]},"arm_right":{"rotation":[(0,Z),(2,[3,0,4]),(4,Z)]},"broom":{"rotation":[(0,Z),(2,[0,0,-4]),(4,Z)]},
 "bread":{"rotation":[(0,Z),(1,[0,0,0]),(1.2,[0,0,-15],L),(1.4,[0,0,15],L),(1.6,Z),(4,Z)]}}))
m.animation("walk",1.2,True,merge(amb(1.2),{"root":{"position":[(0,Z),(.15,[0,1,0]),(.3,Z),(.75,[0,1,0]),(1.2,Z)],"rotation":[(0,[0,0,5]),(.6,[0,0,-5]),(1.2,[0,0,5])]},"body":{"rotation":[(0,[-3,6,0]),(.6,[-3,-6,0]),(1.2,[-3,6,0])]},
 "head":{"rotation":[(0,[0,-6,0]),(.6,[0,6,0]),(1.2,[0,-6,0])]},"leg_left":{"rotation":[(0,[40,0,0]),(.6,[-40,0,0]),(1.2,[40,0,0])]},"leg_right":{"rotation":[(0,[-40,0,0]),(.6,[40,0,0]),(1.2,[-40,0,0])]},"arm_left":{"rotation":[(0,[-20,0,0]),(.6,[20,0,0]),(1.2,[-20,0,0])]},"arm_right":{"rotation":[(0,[10,0,0]),(.6,[-10,0,0]),(1.2,[10,0,0])]}}))
# SWEEP 1.6s loop: sweeping the floor side to side with broom
m.animation("sweep",1.6,True,merge(amb(1.6),{"body":{"rotation":[(0,[-12,20,0]),(.8,[-12,-20,0]),(1.6,[-12,20,0])]},"head":{"rotation":[(0,[15,-15,0]),(.8,[15,15,0]),(1.6,[15,-15,0])]},
 "arm_right":{"rotation":[(0,[30,0,25]),(.8,[30,0,-20]),(1.6,[30,0,25])]},"broom":{"rotation":[(0,[0,0,20]),(.8,[0,0,-30]),(1.6,[0,0,20])]},"arm_left":{"rotation":[(0,[10,0,-20]),(.8,[-10,0,-5]),(1.6,[10,0,-20])]},"root":{"position":[(0,Z),(.4,[0,-.5,0]),(.8,Z),(1.2,[0,-.5,0]),(1.6,Z)]}}))
# SCOLD 2s: stomps foot, shakes fist, brows down
m.animation("scold",2,False,merge({"root":{"position":[(0,Z),(.3,[0,1.5,0]),(.4,[0,-.5,0],L),(.5,Z),(1.0,[0,1.5,0]),(1.1,[0,-.5,0],L),(1.2,Z),(2,Z)]},"body":{"rotation":[(0,Z),(.3,[-15,0,0]),(.6,[-20,10,0]),(.9,[-20,-10,0]),(1.2,[-20,10,0]),(1.5,[-20,-10,0]),(2,Z)]},
 "head":{"rotation":[(0,Z),(.3,[-15,0,0]),(.6,[-15,0,8]),(.9,[-15,0,-8]),(1.2,[-15,0,8]),(1.5,[-15,0,-8]),(2,Z)]},"brows":{"rotation":[(0,Z),(.3,[20,0,0]),(1.6,[20,0,0]),(2,Z)]},
 "arm_left":{"rotation":[(0,Z),(.3,[-90,0,-20]),(.6,[-70,0,-20]),(.8,[-100,0,-20]),(1.0,[-70,0,-20]),(1.2,[-100,0,-20]),(1.4,[-70,0,-20]),(1.6,[-95,0,-20]),(2,Z)]},"leg_left":{"rotation":[(0,Z),(.3,[-40,0,0]),(.4,Z,L),(1.0,[-40,0,0]),(1.1,Z,L),(2,Z)]},
 "broom":{"rotation":[(0,Z),(.3,[0,0,-25]),(1.6,[0,0,-25]),(2,Z)]},"beard":{"rotation":[(0,Z),(.3,[-10,0,0]),(.6,[5,0,0]),(.9,[-8,0,0]),(1.2,[5,0,0]),(1.5,[-8,0,0]),(2,Z)]}},
 {b:{"position":[(0,Z),(.4,[math.cos(i*1.57)*5,6,math.sin(i*1.57)*5]),(1.6,[math.cos(i*1.57)*6,7,math.sin(i*1.57)*6]),(2,Z)]} for i,b in enumerate(embers)}))
# BROOM WHACK 1.1s
m.animation("broom_whack",1.1,False,merge({"body":{"rotation":[(0,Z),(.35,[10,-40,0]),(.55,[-20,35,0]),(.8,[-15,30,0]),(1.1,Z)]},"head":{"rotation":[(0,Z),(.35,[-5,35,0]),(.55,[8,-20,0]),(1.1,Z)]},
 "arm_right":{"rotation":[(0,Z),(.35,[-100,0,50]),(.55,[50,0,-30]),(.8,[45,0,-25]),(1.1,Z)]},"broom":{"rotation":[(0,Z),(.35,[-20,0,30]),(.55,[10,0,-40]),(1.1,Z)]},"arm_left":{"rotation":[(0,Z),(.35,[30,0,-30]),(.55,[-30,0,-10]),(1.1,Z)]},
 "root":{"position":[(0,Z),(.35,[0,1.5,1.5]),(.55,[0,-1,-3]),(1.1,Z)]},"leg_left":{"rotation":[(0,Z),(.55,[-30,0,0]),(1.1,Z)]},"leg_right":{"rotation":[(0,Z),(.55,[25,0,0]),(1.1,Z)]},"brows":{"rotation":[(0,Z),(.35,[20,0,0]),(.9,[15,0,0]),(1.1,Z)]},"beard":{"rotation":[(0,Z),(.35,[-15,0,0]),(.6,[20,0,0]),(1.1,Z)]}}))
# OFFER BREAD 2s: holds bread out, head tilt, happy bounce
m.animation("offer",2,False,merge({"arm_left":{"rotation":[(0,Z),(.5,[70,0,-10]),(1.5,[72,0,-10]),(2,Z)]},"bread":{"rotation":[(0,Z),(.5,[-10,0,15]),(1.5,[-10,0,15]),(2,Z)]},"head":{"rotation":[(0,Z),(.5,[-5,0,-18]),(1.0,[-8,0,-20]),(1.5,[-5,0,18]),(2,Z)]},
 "brows":{"rotation":[(0,Z),(.5,[-20,0,0]),(1.5,[-20,0,0]),(2,Z)]},"body":{"rotation":[(0,Z),(.5,[-8,0,0]),(1.5,[-8,0,0]),(2,Z)]},"root":{"position":[(0,Z),(.8,[0,1,0]),(1.0,Z),(1.2,[0,1,0]),(1.4,Z),(2,Z)]},"beard":{"rotation":[(0,Z),(.8,[-5,0,0]),(1.2,[5,0,0]),(2,Z)]}},
 {b:{"position":[(0,Z),(.6,[0,3,0]),(1.4,[0,3,0]),(2,Z)]} for b in embers}))
# APPEAR 2.5s: pops out from the stove — scale up from tiny with a spin, embers burst
m.animation("appear",2.5,False,merge({"root":{"scale":[(0,[.05,.05,.05],L),(.6,[.05,.05,.05],L),(1.2,[1.15,.85,1.15]),(1.45,[.9,1.15,.9]),(1.7,[1.05,.95,1.05]),(2.0,[1,1,1]),(2.5,[1,1,1])],"rotation":[(0,[0,-720,0],L),(1.5,[0,0,0],L),(2.5,Z)],"position":[(0,[0,-6,0],L),(.6,[0,-6,0]),(1.2,[0,3,0]),(1.5,[0,-.5,0]),(1.8,[0,.5,0]),(2.5,Z)]},
 "arm_left":{"rotation":[(0,[-60,0,-60],L),(1.2,[-60,0,-60]),(1.8,[10,0,-10]),(2.5,Z)]},"arm_right":{"rotation":[(0,[-60,0,60],L),(1.2,[-60,0,60]),(1.8,[10,0,10]),(2.5,Z)]},"head":{"rotation":[(0,Z),(1.2,[-10,0,0]),(1.6,[8,20,0]),(2.0,[0,-15,0]),(2.5,Z)]},"brows":{"rotation":[(0,[-20,0,0],L),(1.4,[-20,0,0]),(2,Z)]}},
 {b:{"position":[(0,Z,L),(1.0,Z),(1.4,[math.cos(i*1.57)*8,6,math.sin(i*1.57)*8]),(2.5,Z)],"scale":[(0,[.05,.05,.05],L),(1.0,[.05,.05,.05],L),(1.3,[2,2,2]),(2.5,[1,1,1])]} for i,b in enumerate(embers)}))
# VANISH 1.5s: shrinks into a spark and drops
m.animation("vanish",1.5,False,merge({"root":{"scale":[(0,[1,1,1],L),(.3,[1.1,.9,1.1]),(.5,[.8,1.2,.8]),(1.2,[.05,.05,.05],L),(1.5,[.05,.05,.05],L)],"rotation":[(0,Z,L),(1.5,[0,540,0],L)],"position":[(0,Z),(.5,[0,3,0]),(1.2,[0,-4,0]),(1.5,[0,-4,0],L)]},
 "arm_left":{"rotation":[(0,Z),(.4,[-40,0,-50]),(1.5,[-40,0,-50],L)]},"arm_right":{"rotation":[(0,Z),(.4,[-40,0,50]),(1.5,[-40,0,50],L)]}},
 {b:{"position":[(0,Z),(1.2,[math.cos(i*1.57)*10,10,math.sin(i*1.57)*10]),(1.5,[math.cos(i*1.57)*10,10,math.sin(i*1.57)*10],L)],"scale":[(0,[1,1,1],L),(1.0,[1,1,1],L),(1.5,[.05,.05,.05],L)]} for i,b in enumerate(embers)}))
m.save("trio/domovoi.bbmodel"); m.save_bedrock_animation("trio/domovoi.animation.json"); print("domovoi",len(m.elements),[a["name"] for a in m.animations])
