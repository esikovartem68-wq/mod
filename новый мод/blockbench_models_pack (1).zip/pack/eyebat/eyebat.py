import sys, math, json, random
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge
import pixelart as px
random.seed(4)
W,FR=128,16
tex=Texture(W,W,FR,name="eyebat",frame_time=3,interpolate=False)
R={"sclera":(0,0,32,32),"iris":(32,0,64,32),"vein":(64,0,96,32),"membrane":(96,0,128,32),"bone":(0,32,32,64),"portal":(32,32,96,96),"ring":(96,32,128,64),"back":(0,64,32,96),"spark":(96,64,128,96),"tendon":(0,96,32,128),"claw":(32,96,64,128),"portal_in":(64,96,96,128)}
for k,r in R.items(): tex.region(k,*r)
base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda k,im: base.paste(im,R[k][:2])
sc=px.noise_tile(32,32,(236,232,214),var=8,bevel=False,seed=1); d=ImageDraw.Draw(sc)
for _ in range(14):
    x,y=random.randint(0,31),random.randint(0,31); pts=[(x,y)]
    for _ in range(4): x+=random.randint(-4,4); y+=random.randint(-3,3); pts.append((x,y))
    d.line(pts,fill=(190,60,60,255))
put("sclera",sc)
bk=px.noise_tile(32,32,(222,218,200),var=10,bevel=False,seed=2); d=ImageDraw.Draw(bk)
for _ in range(20):
    x,y=random.randint(0,31),random.randint(0,31); pts=[(x,y)]
    for _ in range(4): x+=random.randint(-4,4); y+=random.randint(-3,3); pts.append((x,y))
    d.line(pts,fill=(170,50,50,255))
d.ellipse([12,12,20,20],fill=(150,40,50,255)); d.ellipse([14,14,18,18],fill=(90,20,30,255))  # optic nerve stump
put("back",bk)
vn=px.noise_tile(32,32,(170,30,30),var=14,bevel=False,seed=3); d=ImageDraw.Draw(vn)
for y in range(0,32,4): d.line([0,y,31,y+random.randint(-1,1)],fill=(120,15,20,255))
for _ in range(30): x,y=random.randint(0,31),random.randint(0,31); d.point((x,y),fill=(220,70,60,255))
put("vein",vn); put("tendon",px.noise_tile(32,32,(150,25,30),var=10,bands=True,seed=5))
mb=px.noise_tile(32,32,(110,40,52),var=14,bevel=False,seed=4); d=ImageDraw.Draw(mb)
for i in range(0,32,5): d.line([0,i,31,i+3],fill=(150,30,36,255))   # membrane vein streaks
for _ in range(40): x,y=random.randint(0,31),random.randint(0,31); d.point((x,y),fill=(90,30,40,255))
put("membrane",mb); bn=px.noise_tile(32,32,(180,40,40),var=10,bands=True,seed=6); put("bone",bn); put("claw",px.noise_tile(32,32,(60,20,26),var=10,seed=7))
put("iris",Image.new("RGBA",(32,32),(0,0,0,0))); put("portal",Image.new("RGBA",(64,64),(0,0,0,0))); put("ring",Image.new("RGBA",(32,32),(0,0,0,0))); put("spark",Image.new("RGBA",(32,32),(0,0,0,0))); put("portal_in",Image.new("RGBA",(32,32),(0,0,0,0)))
def paint(fr,fi,t):
    d=ImageDraw.Draw(fr); ix,iy=R["iris"][:2]; blink=(fi==13)
    look=(math.sin(t*.9)*.35,math.cos(t*.7)*.25)
    if blink: d.rectangle([ix,iy,ix+31,iy+31],fill=(236,232,214,255)); d.line([ix+2,iy+16,ix+29,iy+16],fill=(190,60,60,255),width=2)
    else:
        d.rectangle([ix,iy,ix+31,iy+31],fill=(236,232,214,255))
        for _ in range(6): x,y=random.randint(0,31),random.randint(0,31); d.line([ix+x,iy+y,ix+x+random.randint(-4,4),iy+y+random.randint(-3,3)],fill=(190,60,60,255))
        cx,cy=ix+16+int(look[0]*8),iy+16+int(look[1]*8)
        d.ellipse([cx-11,cy-11,cx+11,cy+11],fill=(70,50,20,255)); d.ellipse([cx-10,cy-10,cx+10,cy+10],fill=(200,160,40,255))
        for a in range(0,360,20): d.line([cx+math.cos(math.radians(a))*4,cy+math.sin(math.radians(a))*4,cx+math.cos(math.radians(a))*10,cy+math.sin(math.radians(a))*10],fill=(140,100,20,255))
        r=5+int(1.5*math.sin(t*3)); d.ellipse([cx-r,cy-r,cx+r,cy+r],fill=(8,6,4,255)); d.ellipse([cx-4,cy-5,cx-1,cy-2],fill=(255,255,255,255))
    # PORTAL: black/white swirl 64x64, rotating
    px0,py0=R["portal"][:2]; ang=t*1.0
    for y in range(64):
        for x in range(64):
            dx,dy=x-31.5,y-31.5; rr=math.hypot(dx,dy)/32
            if rr>1: continue
            a=math.atan2(dy,dx)+ang+rr*5
            v=math.sin(a*3)+math.sin(rr*18-t*4)*.6
            g=255 if v>.2 else (0 if v<-.2 else 128)
            alpha=255 if rr>.25 else 200
            fr.putpixel((px0+x,py0+y),(g,g,g,alpha))
    rx,ry=R["ring"][:2]
    for y in range(32):
        for x in range(32):
            dx,dy=x-15.5,y-15.5; rr=math.hypot(dx,dy)/16
            if rr>1 or rr<.62: continue
            a=math.atan2(dy,dx)-ang*2; g=255 if math.sin(a*8)>0 else 0
            fr.putpixel((rx+x,ry+y),(g,g,g,255))
    pi,pj=R["portal_in"][:2]
    for y in range(32):
        for x in range(32):
            dx,dy=x-15.5,y-15.5; rr=math.hypot(dx,dy)/16
            if rr>1: continue
            v=math.sin(rr*14-t*5); g=int(128+127*v); fr.putpixel((pi+x,pj+y),(g,g,g,int(255*(1-rr*.6))))
    sx,sy=R["spark"][:2]
    for i in range(20):
        x=(i*11+fi*3)%32; y=(i*7-fi*2)%32; g=255 if i%2 else 0; d.rectangle([sx+x,sy+y,sx+x+1,sy+y+1],fill=(g,g,g,int(120+120*math.sin(t*3+i))))
random.seed(8); strip=px.make_strip(base,FR,paint); tex.set_image(strip); strip.save("eyebat/eyebat.png"); json.dump(tex.mcmeta(),open("eyebat/eyebat.png.mcmeta","w"))

m=Model("eyebat",tex,fmt="free",seed=6)
m.bone("root",[0,0,0]); m.bone("portal",[0,14,10],"root"); m.bone("portal_ring",[0,14,10],"portal"); m.bone("body",[0,12,0],"root"); m.bone("eye",[0,12,0],"body")
m.bone("wing_l",[4,14,1],"body",rot=[0,0,-10]); m.bone("wing_l2",[12,17,1],"wing_l"); m.bone("wing_l3",[20,16,1],"wing_l2")
m.bone("wing_r",[-4,14,1],"body",rot=[0,0,10]); m.bone("wing_r2",[-12,17,1],"wing_r"); m.bone("wing_r3",[-20,16,1],"wing_r2")
m.bone("nerve",[0,10,4],"body"); m.bone("nerve2",[0,8,7],"nerve")
for i in range(6): m.bone(f"spark_{i}",[0,14,10],"portal")
# --- eyeball: 10-unit sphere-ish stack
m.cube("eye_core",[-5,7,-5],[5,17,5],"sclera","eye",faces={"north":"iris","south":"back"}); m.cube("eye_cap_top",[-4,17,-4],[4,18,4],"sclera","eye"); m.cube("eye_cap_bot",[-4,6,-4],[4,7,4],"sclera","eye")
m.cube("eye_r1",[-5.5,8,-4],[5.5,16,4],"sclera","eye"); m.cube("eye_r2",[-4,8,-5.5],[4,16,5.5],"sclera","eye",faces={"north":"iris","south":"back"})
m.cube("iris_bulge",[-3,9,-6],[3,15,-5.4],"iris","eye",full=True)
m.cube("vein_l",[4,11,-4],[5.8,13,3],"vein","eye"); m.cube("vein_r",[-5.8,11,-4],[-4,13,3],"vein","eye"); m.cube("vein_t",[-3,16.5,-3],[3,18.2,3],"vein","eye")
m.cube("lid_top",[-5.6,15,-5.6],[5.6,16.5,-1],"vein","eye",rot=[-20,0,0],origin=[0,15,-1])
# tendons from top of eye to wings
m.cube("tendon_l",[3,14,0],[8,16.5,2],"tendon","wing_l",rot=[0,0,25],origin=[4,15,1]); m.cube("tendon_r",[-8,14,0],[-3,16.5,2],"tendon","wing_r",rot=[0,0,-25],origin=[-4,15,1])
# --- wings: bat-like, 3 joints each, red bones + membrane
for sgn,w1,w2,w3 in ((1,"wing_l","wing_l2","wing_l3"),(-1,"wing_r","wing_r2","wing_r3")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(4,12.5); m.cube(f"{w1}_bone",[xa,16,.4],[xb,17.8,1.6],"bone",w1,rot=[0,0,sgn*-20],origin=[sgn*4,16,1])
    xa,xb=X(4,12); m.cube(f"{w1}_mem",[xa,9,.6],[xb,16,1.4],"membrane",w1,rot=[0,0,sgn*-20],origin=[sgn*4,16,1]); xa,xb=X(4.5,10); m.cube(f"{w1}_mem2",[xa,4,.7],[xb,9.5,1.3],"membrane",w1,rot=[0,0,sgn*-20],origin=[sgn*4,16,1])
    xa,xb=X(12,21); m.cube(f"{w2}_bone",[xa,16,.4],[xb,17.5,1.6],"bone",w2,rot=[0,0,sgn*10],origin=[sgn*12,17,1])
    xa,xb=X(12,20.5); m.cube(f"{w2}_mem",[xa,8,.6],[xb,16,1.4],"membrane",w2,rot=[0,0,sgn*10],origin=[sgn*12,17,1]); xa,xb=X(12,18); m.cube(f"{w2}_mem2",[xa,3,.7],[xb,8.5,1.3],"membrane",w2,rot=[0,0,sgn*10],origin=[sgn*12,17,1])
    xa,xb=X(12,13.2); m.cube(f"{w2}_finger",[xa,7,.5],[xb,17,1.5],"bone",w2,rot=[0,0,sgn*10],origin=[sgn*12,17,1])   # wing finger
    xa,xb=X(20,29); m.cube(f"{w3}_bone",[xa,15.5,.4],[xb,17,1.6],"bone",w3,rot=[0,0,sgn*25],origin=[sgn*20,16,1])
    xa,xb=X(20,28); m.cube(f"{w3}_mem",[xa,9,.6],[xb,15.8,1.4],"membrane",w3,rot=[0,0,sgn*25],origin=[sgn*20,16,1]); xa,xb=X(20,25); m.cube(f"{w3}_mem2",[xa,5,.7],[xb,9.5,1.3],"membrane",w3,rot=[0,0,sgn*25],origin=[sgn*20,16,1])
    xa,xb=X(20,21.2); m.cube(f"{w3}_finger",[xa,9,.5],[xb,16,1.5],"bone",w3,rot=[0,0,sgn*25],origin=[sgn*20,16,1])
    xa,xb=X(28,31); m.cube(f"{w3}_claw",[xa,16,.5],[xb,18.5,1.5],"claw",w3,rot=[0,0,sgn*60],origin=[sgn*28,16.5,1]); xa,xb=X(26,27.2); m.cube(f"{w3}_tip_finger",[xa,8,.5],[xb,16,1.5],"bone",w3,rot=[0,0,sgn*25],origin=[sgn*20,16,1])
# optic nerve tail
m.cube("nerve",[-1,9,4],[1,11,8],"tendon","nerve",rot=[25,0,0],origin=[0,10,4]); m.cube("nerve2",[-.7,7.5,7],[.7,9,11],"tendon","nerve2",rot=[35,0,0],origin=[0,8,7])
# portal (flat disc facing -Z, behind the bat)
m.cube("portal_disc",[-14,0,9.8],[14,28,10.2],"portal","portal",full=True); m.cube("portal_inner",[-8,6,9.5],[8,22,9.7],"portal_in","portal",full=True)
m.cube("portal_ring",[-16,-2,9.6],[16,30,10.4],"ring","portal_ring",full=True,faces={"north":"ring","south":"ring","up":"spark","down":"spark","east":"spark","west":"spark"})
for i in range(6):
    a=i*60; x,y=math.cos(math.radians(a))*13,14+math.sin(math.radians(a))*13
    m.cube(f"spark_{i}",[x-1,y-1,9],[x+1,y+1,11],"spark",f"spark_{i}",full=True,rot=[0,0,45],origin=[x,y,10])
Z=[0,0,0]; L="linear"; S0=[0,0,0]; S1=[1,1,1]; sparks=[f"spark_{i}" for i in range(6)]
NOPORTAL={b:{"scale":[(0,S0)]} for b in ["portal","portal_ring"]+sparks}
def flap(length,cycles,amp=45,glide=0):
    n=cycles*4; ks=lambda a,ph: [(length*k/n,[0,0,a*math.sin(2*math.pi*k/n*cycles+ph)]) for k in range(n+1)]
    d={}
    for sgn,w1,w2,w3 in ((1,"wing_l","wing_l2","wing_l3"),(-1,"wing_r","wing_r2","wing_r3")):
        d[w1]={"rotation":[(t,[0,0,sgn*(-v[2]+glide)]) for t,v in ks(amp,0)]}; d[w2]={"rotation":[(t,[0,0,sgn*(-v[2]*.7)]) for t,v in ks(amp,-.8)]}; d[w3]={"rotation":[(t,[0,0,sgn*(-v[2]*.6)]) for t,v in ks(amp,-1.6)]}
    return d
def bob(length,cycles,amp=1.5): n=cycles*4; return {"body":{"position":[(length*k/n,[0,amp*math.sin(2*math.pi*k/n*cycles-1.2),0]) for k in range(n+1)]}}
def nerve(length,cycles): n=cycles*4; return {"nerve":{"rotation":[(length*k/n,[12*math.sin(2*math.pi*k/n*cycles+.5),0,0]) for k in range(n+1)]},"nerve2":{"rotation":[(length*k/n,[15*math.sin(2*math.pi*k/n*cycles-.4),0,0]) for k in range(n+1)]}}
m.animation("fly",1.0,True,merge(NOPORTAL,flap(1.0,2),bob(1.0,2),nerve(1.0,2),{"eye":{"rotation":[(0,Z),(.5,[3,0,0]),(1,Z)]}}))
m.animation("hover",2.0,True,merge(NOPORTAL,flap(2.0,3,35),bob(2.0,3,1),nerve(2.0,3),{"eye":{"rotation":[(0,Z),(.5,[0,25,0]),(1.0,[5,0,0]),(1.5,[0,-25,0]),(2,Z)]}}))
m.animation("glide",2.0,True,merge(NOPORTAL,flap(2.0,1,6,-5),nerve(2.0,1),{"body":{"rotation":[(0,[0,0,4]),(1,[0,0,-4]),(2,[0,0,4])],"position":[(0,Z),(1,[0,-1,0]),(2,Z)]}}))
m.animation("dive_attack",1.4,False,merge(NOPORTAL,flap(1.4,3,50),nerve(1.4,3),{"body":{"rotation":[(0,Z),(.3,[-10,0,0]),(.6,[45,0,0]),(.9,[40,0,0]),(1.4,Z)],"position":[(0,Z),(.3,[0,4,3]),(.7,[0,-8,-12]),(1.0,[0,-6,-10]),(1.4,Z)]},"eye":{"rotation":[(0,Z),(.6,[-15,0,0]),(1.4,Z)],"scale":[(0,S1),(.3,[1.1,1.1,1.1]),(.7,[.95,.95,1.1]),(1.4,S1)]}}))
m.animation("stare",2.5,False,merge(NOPORTAL,flap(2.5,3,20),{"eye":{"scale":[(0,S1),(.4,[1.25,1.25,1.25]),(2.0,[1.25,1.25,1.25]),(2.5,S1)],"rotation":[(0,Z),(.4,[-8,0,0]),(.8,[-8,0,4]),(1.2,[-8,0,-4]),(1.6,[-8,0,4]),(2.0,[-8,0,0]),(2.5,Z)]}}))
# PORTAL SPAWN 3.5s: portal opens behind (scale up + spin), bat is tiny at portal centre, shoots out toward -Z, portal closes
PS={"portal":{"scale":[(0,S0,L),(.2,S0),(.7,[1.2,1.2,1]),(1.0,S1),(2.4,S1),(2.9,[1.15,.1,1]),(3.1,S0,L),(3.5,S0,L)],"rotation":[(0,Z,L),(3.5,[0,0,-540],L)]},
 "portal_ring":{"scale":[(0,S0,L),(.2,S0),(.8,[1.3,1.3,1]),(1.1,S1),(2.4,S1),(3.0,S0,L),(3.5,S0,L)],"rotation":[(0,Z,L),(3.5,[0,0,900],L)]},
 "body":{"position":[(0,[0,2,10],L),(1.0,[0,2,10],L),(1.5,[0,4,4]),(2.0,[0,-2,-8]),(2.5,[0,1,-12]),(3.0,[0,0,-11]),(3.5,[0,0,-11])],"scale":[(0,S0,L),(1.0,S0,L),(1.1,[.2,.2,.2]),(1.6,[1.15,1.15,1.15]),(1.9,S1),(3.5,S1)],"rotation":[(0,[0,0,360],L),(1.0,[0,0,360],L),(1.7,[0,0,0]),(2.0,[-25,0,0]),(2.5,[10,0,0]),(3.5,Z)]},
 "eye":{"rotation":[(0,Z),(1.9,Z),(2.3,[0,30,0]),(2.7,[0,-30,0]),(3.1,[0,0,0]),(3.5,Z)],"scale":[(0,S1),(1.9,S1),(2.1,[1.3,1.3,1.3]),(2.4,S1),(3.5,S1)]}}
for sgn,w1,w2,w3 in ((1,"wing_l","wing_l2","wing_l3"),(-1,"wing_r","wing_r2","wing_r3")):
    PS[w1]={"rotation":[(0,[0,0,sgn*-80]),(1.3,[0,0,sgn*-80]),(1.7,[0,0,sgn*40]),(1.9,[0,0,sgn*-40]),(2.1,[0,0,sgn*40]),(2.3,[0,0,sgn*-40]),(2.5,[0,0,sgn*40]),(2.75,[0,0,sgn*-40]),(3.0,[0,0,sgn*40]),(3.25,[0,0,sgn*-40]),(3.5,[0,0,sgn*40])]}
    PS[w2]={"rotation":[(0,[0,0,sgn*-100]),(1.3,[0,0,sgn*-100]),(1.75,[0,0,sgn*20]),(1.95,[0,0,sgn*-25]),(2.15,[0,0,sgn*25]),(2.35,[0,0,sgn*-25]),(2.55,[0,0,sgn*25]),(2.8,[0,0,sgn*-25]),(3.05,[0,0,sgn*25]),(3.3,[0,0,sgn*-25]),(3.5,[0,0,sgn*25])]}
    PS[w3]={"rotation":[(0,[0,0,sgn*-90]),(1.3,[0,0,sgn*-90]),(1.8,[0,0,sgn*15]),(2.0,[0,0,sgn*-20]),(2.2,[0,0,sgn*20]),(2.4,[0,0,sgn*-20]),(2.6,[0,0,sgn*20]),(2.85,[0,0,sgn*-20]),(3.1,[0,0,sgn*20]),(3.35,[0,0,sgn*-20]),(3.5,[0,0,sgn*20])]}
for i,b in enumerate(sparks):
    a=i*1.05; PS[b]={"scale":[(0,S0,L),(.5,S0,L),(.8,[1.5,1.5,1.5]),(1.2,S1),(2.4,S1),(2.9,S0,L),(3.5,S0,L)],"position":[(0,Z),(.6,Z),(1.2,[math.cos(a)*4,math.sin(a)*4,-2]),(2.4,[math.cos(a+2)*6,math.sin(a+2)*6,-4]),(3.0,Z)],"rotation":[(0,Z,L),(3.5,[0,0,720],L)]}
m.animation("portal_spawn",3.5,False,PS)
# PORTAL RETURN 2.5s: flies back into portal and it snaps shut
PR={"portal":{"scale":[(0,S0,L),(.3,[1.2,1.2,1]),(.6,S1),(1.8,S1),(2.2,[1.1,.1,1]),(2.4,S0,L),(2.5,S0,L)],"rotation":[(0,Z,L),(2.5,[0,0,400],L)]},"portal_ring":{"scale":[(0,S0,L),(.3,[1.3,1.3,1]),(.6,S1),(1.8,S1),(2.3,S0,L),(2.5,S0,L)],"rotation":[(0,Z,L),(2.5,[0,0,-700],L)]},
 "body":{"position":[(0,Z),(.5,[0,3,-3]),(1.0,[0,2,2]),(1.6,[0,2,10]),(2.5,[0,2,10],L)],"scale":[(0,S1),(1.2,S1),(1.6,[.15,.15,.15]),(1.7,S0,L),(2.5,S0,L)],"rotation":[(0,Z),(.5,[20,0,0]),(1.6,[0,0,-360]),(2.5,[0,0,-360],L)]}}
PR.update(flap(2.5,4,45))
for i,b in enumerate(sparks): a=i*1.05; PR[b]={"scale":[(0,S0,L),(.3,[1.5,1.5,1.5]),(.7,S1),(1.8,S1),(2.3,S0,L),(2.5,S0,L)],"position":[(0,Z),(.7,[math.cos(a)*5,math.sin(a)*5,-3]),(1.8,[math.cos(a+2)*3,math.sin(a+2)*3,-1]),(2.5,Z)]}
m.animation("portal_return",2.5,False,PR)
m.animation("death",1.6,False,merge(NOPORTAL,{"body":{"rotation":[(0,Z),(.3,[-20,0,30]),(.8,[40,0,120]),(1.3,[60,0,180]),(1.6,[60,0,180],L)],"position":[(0,Z),(.3,[0,2,0]),(1.3,[0,-11,0]),(1.6,[0,-11,0],L)]},"eye":{"scale":[(0,S1),(.3,[1.3,1.3,1.3]),(.6,[.9,.9,.9]),(1.6,[.85,.85,.85])]},
 "wing_l":{"rotation":[(0,Z),(.3,[0,0,-70]),(.8,[0,0,40]),(1.3,[0,0,60]),(1.6,[0,0,60],L)]},"wing_r":{"rotation":[(0,Z),(.3,[0,0,70]),(.8,[0,0,-40]),(1.3,[0,0,-60]),(1.6,[0,0,-60],L)]},"wing_l2":{"rotation":[(0,Z),(1.3,[0,0,-70]),(1.6,[0,0,-70],L)]},"wing_r2":{"rotation":[(0,Z),(1.3,[0,0,70]),(1.6,[0,0,70],L)]},"wing_l3":{"rotation":[(0,Z),(1.3,[0,0,-60]),(1.6,[0,0,-60],L)]},"wing_r3":{"rotation":[(0,Z),(1.3,[0,0,60]),(1.6,[0,0,60],L)]}}))
m.save("eyebat/eyebat.bbmodel"); m.save_bedrock_animation("eyebat/eyebat.animation.json"); print("eyebat",len(m.elements),[a["name"] for a in m.animations])
