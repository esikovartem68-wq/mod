import sys, math, json
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge, wave, hover
import pixelart as px
W,FR=128,8
tex=Texture(W,W,FR,name="gravedigger",frame_time=3)
for k,r in {"coat":(0,0,32,64),"dcoat":(32,0,64,64),"skin":(64,0,96,32),"bone":(96,0,128,32),"wood":(64,32,96,64),"iron":(96,32,128,64),"face":(0,64,32,96),"chest":(32,64,64,96),"lantern":(64,64,96,96),"sack":(96,64,128,96),"dirt":(0,96,32,128),"beard":(32,96,64,128),"flame":(64,96,96,128),"eye":(96,96,128,128)}.items(): tex.region(k,*r)
base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda k,im: base.paste(im,tex.regions[k][:2])
c=px.noise_tile(32,64,(38,34,30),var=12,bands=True,seed=1); d=ImageDraw.Draw(c)
for _ in range(10): x,y=px.random.randint(1,29),px.random.randint(1,61); d.line([x,y,x+1,y+4],fill=(20,18,16,255))
for _ in range(8): x,y=px.random.randint(1,27),px.random.randint(1,59); d.rectangle([x,y,x+3,y+3],fill=(60,52,40,255)); d.rectangle([x,y,x+3,y+3],outline=(30,26,22,255))   # patches
put("coat",c); put("dcoat",px.noise_tile(32,64,(24,22,20),var=8,seed=2))
put("skin",px.noise_tile(32,32,(150,140,118),var=16,seed=3)); sk=base.crop((64,0,96,32)); px.blotches(sk,10,-24,seed=3); put("skin",sk)
put("bone",px.noise_tile(32,32,(214,206,184),var=12,seed=4))
w=px.noise_tile(32,32,(92,66,40),var=14,bands=True,layers_freq=.3,seed=5); dw=ImageDraw.Draw(w)
for x in range(0,32,5): dw.line([x,0,x,31],fill=(60,42,26,255))
put("wood",w); ir=px.noise_tile(32,32,(72,74,78),var=10,seed=6); px.rust(ir,12,seed=6); put("iron",ir)
put("sack",px.noise_tile(32,32,(122,104,72),var=16,bands=True,seed=7)); sa=base.crop((96,64,128,96)); dsa=ImageDraw.Draw(sa)
for y in range(0,32,4): dsa.line([0,y,31,y+1],fill=(96,80,54,255))
dsa.line([6,10,10,14,8,20],fill=(60,48,30,255),width=2); put("sack",sa)
di=px.noise_tile(32,32,(78,58,38),var=18,bevel=False,seed=8); px.speckle(di,40,seed=8); put("dirt",di)
bd=px.noise_tile(32,32,(178,174,166),var=14,bevel=False,seed=9); dbd=ImageDraw.Draw(bd)
for x in range(0,32,2): dbd.line([x,0,x+px.random.randint(-1,1),31],fill=(140,136,128,255))
put("beard",bd)
la=Image.new("RGBA",(32,32),(0,0,0,0)); dl=ImageDraw.Draw(la); dl.rectangle([0,0,31,31],fill=(255,200,120,120)); 
for x in (0,31): dl.line([x,0,x,31],fill=(60,60,64,255))
for y in (0,31): dl.line([0,y,31,y],fill=(60,60,64,255))
for x in (10,21): dl.line([x,0,x,31],fill=(60,60,64,255))
put("lantern",la)
f=px.noise_tile(32,32,(150,140,118),var=16,seed=10); df=ImageDraw.Draw(f); px.blotches(f,8,-26,seed=10)
df.rectangle([0,0,31,7],fill=(24,22,20,255))                       # hat shadow / brim
df.rectangle([4,9,12,15],fill=(20,14,12,255)); df.rectangle([19,9,27,15],fill=(20,14,12,255))     # sunken sockets
df.line([3,8,13,10],fill=(90,80,66,255),width=2); df.line([18,10,28,8],fill=(90,80,66,255),width=2)  # heavy brows
df.polygon([(14,16),(18,16),(17,21),(15,21)],fill=(110,96,80,255)); df.line([15,21,17,21],fill=(40,30,26,255))
df.rectangle([9,24,23,26],fill=(40,24,20,255)); 
for x in range(10,23,3): df.rectangle([x,24,x,25],fill=(190,180,140,255))
for x in range(0,32,2): df.line([x,26,x+px.random.randint(-1,1),31],fill=(178,174,166,255))     # beard start
df.line([2,18,5,24],fill=(80,60,50,255)); df.line([27,14,29,22],fill=(80,60,50,255))
put("face",f)
ch=px.noise_tile(32,32,(38,34,30),var=12,bands=True,seed=11); dch=ImageDraw.Draw(ch)
dch.line([16,0,16,31],fill=(20,18,16,255),width=2)
for y in range(5,30,7): dch.ellipse([14,y,17,y+3],fill=(110,100,80,255)); dch.point((15,y+1),fill=(160,150,120,255))   # buttons
dch.rectangle([2,4,8,10],fill=(60,52,40,255)); dch.rectangle([2,4,8,10],outline=(30,26,22,255))
dch.line([22,12,26,20],fill=(120,20,24,255),width=2)   # blood streak
put("chest",ch); put("flame",Image.new("RGBA",(32,32),(0,0,0,0))); put("eye",Image.new("RGBA",(32,32),(0,0,0,0)))
def paint(fr,fi,t):
    d=ImageDraw.Draw(fr); k=(math.sin(t)+1)/2; fl=(math.sin(t*3)+math.sin(t*5+1))/4+.5
    fx,fy=tex.regions["flame"][:2]; d.ellipse([fx+6,fy+6,fx+25,fy+25],fill=(255,140,40,150)); d.ellipse([fx+9,fy+9-int(3*fl),fx+22,fy+24],fill=(255,190,80,255)); d.ellipse([fx+13,fy+13-int(2*fl),fx+18,fy+21],fill=(255,240,200,255))
    lx,ly=tex.regions["lantern"][:2]; d.rectangle([lx+1,ly+1,lx+9,ly+30],fill=(255,int(190+40*fl),120,int(110+50*fl))); d.rectangle([lx+11,ly+1,lx+20,ly+30],fill=(255,int(190+40*fl),120,int(110+50*fl))); d.rectangle([lx+22,ly+1,lx+30,ly+30],fill=(255,int(190+40*fl),120,int(110+50*fl)))
    ffx,ffy=tex.regions["face"][:2]
    for cx in (8,23): d.rectangle([ffx+cx-1,ffy+11,ffx+cx+1,ffy+13],fill=(int(120+100*k),int(200+55*k),int(120+60*k),255)); d.point((ffx+cx,ffy+12),fill=(240,255,240,255))
    ex,ey=tex.regions["eye"][:2]; d.ellipse([ex+8,ey+8,ex+23,ey+23],fill=(int(120+100*k),int(200+55*k),int(140+60*k),255)); d.ellipse([ex+13,ey+13,ex+18,ey+18],fill=(240,255,240,255))
strip=px.make_strip(base,FR,paint); tex.set_image(strip); strip.save("trio/gravedigger.png"); json.dump(tex.mcmeta(),open("trio/gravedigger.png.mcmeta","w"))

m=Model("gravedigger",tex,fmt="free",seed=9)
m.bone("root",[0,0,0]); m.bone("body",[0,12,0],"root",rot=[-32,0,0]); m.bone("head",[0,23,-4],"body",rot=[22,0,-6]); m.bone("jaw",[0,24,-6],"head",rot=[-8,0,0]); m.bone("hat",[0,32,-4],"head",rot=[8,0,5])
m.bone("arm_left",[5,22,-2],"body",rot=[40,0,-8]); m.bone("forearm_left",[6,15,-6],"arm_left",rot=[-60,0,0]); m.bone("shovel",[7,12,-10],"forearm_left",rot=[20,0,0])
m.bone("arm_right",[-5,22,-2],"body",rot=[30,0,10]); m.bone("forearm_right",[-6,15,-5],"arm_right",rot=[-50,0,0]); m.bone("lantern",[-7,9,-9],"forearm_right",rot=[10,0,0])
m.bone("leg_left",[2,12,0],"root",rot=[6,0,-2]); m.bone("leg_right",[-2,12,0],"root",rot=[-10,0,3])
m.bone("sack",[0,22,3],"body"); m.bone("coat_tail",[0,12,2],"body"); m.bone("beard",[0,25,-8],"head")
for i in range(3): m.bone(f"wisp_{i}",[-7,12,-9],"lantern")
m.cube("torso",[-4.5,12,-2.5],[4.5,24,3],"coat","body",faces={"north":"chest"}); m.cube("hump",[-4,22,1],[4,27,6],"dcoat","body"); m.cube("collar",[-4.8,23,-3.5],[4.8,25,3],"dcoat","body")
m.cube("belt",[-4.8,13.5,-3],[4.8,15.5,3.5],"dcoat","body"); m.cube("buckle",[-1,13.3,-3.3],[1,15.7,-2.8],"iron","body")
for i,(x,y) in enumerate(((3,16),(-3.5,19))): m.cube(f"tool_{i}",[x-.4,y,-3.2],[x+.4,y+5,-2.6],"iron","body",rot=[0,0,15 if x>0 else -10],origin=[x,y+5,-3])
m.cube("coat_tail_l",[-4.6,4,0],[-.2,12.5,3.2],"coat","coat_tail",rot=[8,0,4],origin=[-2.4,12,1.6]); m.cube("coat_tail_r",[.2,3,0],[4.6,12.5,3.2],"coat","coat_tail",rot=[8,0,-4],origin=[2.4,12,1.6])
m.cube("coat_front_l",[-4.6,7,-3],[-.5,12.5,-1.5],"coat","coat_tail",rot=[-6,0,0]); m.cube("coat_front_r",[.5,8,-3],[4.6,12.5,-1.5],"coat","coat_tail",rot=[-6,0,0])
m.cube("neck",[-1.5,22,-5],[1.5,25,-2],"skin","head")
m.cube("skull",[-4,24,-8.5],[4,32,-.5],"skin","head",faces={"north":"face"}); m.cube("nose",[-.8,27.5,-9.4],[.8,29.5,-8.4],"skin","head")
m.cube("eye_l",[-2.9,28.3,-8.9],[-1.3,29.9,-8.4],"eye","head",full=True); m.cube("eye_r",[1.3,28.3,-8.9],[2.9,29.9,-8.4],"eye","head",full=True)
m.cube("ear_l",[-4.8,27,-4],[-4,30,-1.5],"skin","head"); m.cube("ear_r",[4,27,-4],[4.8,30,-1.5],"skin","head")
m.cube("jaw",[-3.2,22.5,-8.6],[3.2,24.5,-2],"skin","jaw"); m.cube("beard_main",[-3.4,15,-9],[3.4,25,-6.5],"beard","beard",rot=[-6,0,0]); m.cube("beard_tip",[-1.6,10,-9.2],[1.6,16,-7.4],"beard","beard",rot=[-12,0,0]); m.cube("mustache",[-3,24.5,-9.2],[3,26,-8.4],"beard","head")
m.cube("hat_brim",[-7,31.5,-11],[7,32.5,3],"dcoat","hat"); m.cube("hat_crown",[-4.5,32.5,-8],[4.5,39,0],"dcoat","hat"); m.cube("hat_band",[-4.8,33,-8.3],[4.8,34.5,.3],"coat","hat"); m.cube("hat_dent",[-2,38,-6],[3,39.5,-1],"coat","hat",rot=[0,0,-8]); m.cube("hat_crow_feather",[3,36,-4],[4,42,-3],"beard","hat",rot=[0,0,-30],origin=[3.5,36,-3.5])
for sgn,a,fa in ((1,"arm_left","forearm_left"),(-1,"arm_right","forearm_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(4,8); m.cube(f"sleeve_{a}",[xa,15,-4],[xb,23,0],"coat",a); xa,xb=X(3.8,8.2); m.cube(f"shoulder_{a}",[xa,21,-4.5],[xb,24,.5],"dcoat",a)
    xa,xb=X(4.3,7.7); m.cube(f"fore_{a}",[xa,9,-7.5],[xb,16,-4],"coat",fa); xa,xb=X(4.5,7.5); m.cube(f"hand_{a}",[xa,6.5,-8],[xb,9.5,-4],"bone",fa)
    for i in range(3): xa,xb=X(4.7+i*.9,5.3+i*.9); m.cube(f"finger_{a}_{i}",[xa,4.5,-8],[xb,6.5,-7],"bone",fa,rot=[-25,0,0],origin=[(xa+xb)/2,6.5,-7.5])
m.cube("shovel_shaft",[6.5,-4,-10.5],[7.5,18,-9.5],"wood","shovel"); m.cube("shovel_grip",[5.5,18,-11],[8.5,20,-9],"wood","shovel"); m.cube("shovel_blade",[4,-12,-11],[10,-4,-9.5],"iron","shovel"); m.cube("shovel_blade_tip",[5,-14,-11],[9,-12,-9.5],"iron","shovel"); m.cube("shovel_dirt",[4.5,-11,-11.8],[9.5,-6,-11],"dirt","shovel",full=True)
m.cube("lantern_handle",[-7.5,8,-9.5],[-6.5,10,-8.5],"iron","lantern"); m.cube("lantern_top",[-9,7,-11],[-5,8,-7],"iron","lantern"); m.cube("lantern_glass",[-8.5,1,-10.5],[-5.5,7,-7.5],"lantern","lantern",full=True); m.cube("lantern_flame",[-7.7,2,-9.7],[-6.3,5.5,-8.3],"flame","lantern",full=True); m.cube("lantern_base",[-9,0,-11],[-5,1,-7],"iron","lantern")
for i in range(3):
    a=math.radians(i*120); x,z=-7+math.cos(a)*4,-9+math.sin(a)*4; y=2+i*2
    m.cube(f"wisp_{i}",[x-.5,y-.5,z-.5],[x+.5,y+.5,z+.5],"flame",f"wisp_{i}",full=True)
for sgn,lg in ((1,"leg_left"),(-1,"leg_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(.3,4); m.cube(f"thigh_{lg}",[xa,5,-2],[xb,12,2],"dcoat",lg); xa,xb=X(.5,3.8); m.cube(f"shin_{lg}",[xa,1,-1.8],[xb,5.5,1.8],"dcoat",lg); xa,xb=X(0,4.3); m.cube(f"boot_{lg}",[xa,0,-3.5],[xb,2,2],"iron",lg); xa,xb=X(.4,3.9); m.cube(f"boot_top_{lg}",[xa,2,-2.2],[xb,3.5,2.2],"iron",lg)
m.cube("sack",[-4,17,3],[4,27,9],"sack","sack",rot=[-10,0,0],full=True); m.cube("sack_neck",[-1.5,27,4],[1.5,30,7],"sack","sack",rot=[-10,0,0]); m.cube("sack_rope",[-1.8,27.5,3.7],[1.8,28.5,7.3],"dcoat","sack",rot=[-10,0,0]); m.cube("sack_bone",[-1,29,3],[0,34,4],"bone","sack",rot=[-30,0,10],origin=[-.5,29,3.5]); m.cube("sack_skull",[1,29.5,3.5],[4,32.5,6.5],"bone","sack",rot=[-10,20,0])
Z=[0,0,0]; L="linear"; wisps=[f"wisp_{i}" for i in range(3)]
def amb(length): return merge(wave("lantern",length,6,1,0,axis=0),wave("lantern",length,4,1,.8,axis=2),wave("beard",length,3),wave("coat_tail",length,3,1,.4),
 {b:{"position":[(length*k/8,[math.cos(2*math.pi*k/8+i*2.1)*1.2,math.sin(4*math.pi*k/8+i)*.8,math.sin(2*math.pi*k/8+i*2.1)*1.2]) for k in range(9)]} for i,b in enumerate(wisps)})
m.animation("idle",4,True,merge(amb(4),{"body":{"rotation":[(0,Z),(2,[-2,0,0]),(4,Z)]},"root":{"position":[(0,Z),(2,[0,-.5,0]),(4,Z)]},"head":{"rotation":[(0,Z),(1.2,[-3,14,0]),(2.4,[2,-12,2]),(4,Z)]},
 "jaw":{"rotation":[(0,Z),(1.5,[-8,0,0]),(2,Z),(2.6,[-6,0,0]),(4,Z)]},"arm_left":{"rotation":[(0,Z),(2,[3,0,-3]),(4,Z)]},"shovel":{"rotation":[(0,Z),(2,[3,0,0]),(4,Z)]},"arm_right":{"rotation":[(0,Z),(2,[4,0,3]),(4,Z)]}}))
m.animation("walk",2,True,merge(amb(2),{"root":{"position":[(0,Z),(.25,[0,1,0]),(.5,[0,-.5,0]),(1,Z),(1.25,[0,1,0]),(1.5,[0,-.5,0]),(2,Z)],"rotation":[(0,[0,0,3]),(1,[0,0,-3]),(2,[0,0,3])]},
 "body":{"rotation":[(0,[-3,6,0]),(.5,[-6,0,0]),(1,[-3,-6,0]),(1.5,[-6,0,0]),(2,[-3,6,0])]},"head":{"rotation":[(0,[2,-6,0]),(1,[2,6,0]),(2,[2,-6,0])]},
 "leg_left":{"rotation":[(0,[30,0,0]),(1,[-25,0,0]),(2,[30,0,0])]},"leg_right":{"rotation":[(0,[-25,0,0]),(1,[30,0,0]),(2,[-25,0,0])]},"arm_left":{"rotation":[(0,[-10,0,0]),(1,[10,0,0]),(2,[-10,0,0])]},"arm_right":{"rotation":[(0,[10,0,0]),(1,[-10,0,0]),(2,[10,0,0])]},"sack":{"rotation":[(0,[-4,0,3]),(1,[4,0,-3]),(2,[-4,0,3])]}}))
# DIG 2.4s loop: shovel into ground, lift, toss dirt over shoulder
m.animation("dig",2.4,True,merge(amb(2.4),{"body":{"rotation":[(0,Z),(.5,[-20,-10,0]),(.7,[-22,-10,0]),(1.2,[5,-5,0]),(1.7,[15,35,0]),(2.4,Z)]},"head":{"rotation":[(0,Z),(.6,[15,0,0]),(1.7,[-10,-30,0]),(2.4,Z)]},
 "arm_left":{"rotation":[(0,Z),(.5,[20,0,-10]),(.7,[25,0,-10]),(1.2,[-40,0,-15]),(1.7,[-80,20,-40]),(2.4,Z)]},"forearm_left":{"rotation":[(0,Z),(.5,[20,0,0]),(1.2,[-10,0,0]),(1.7,[-30,0,0]),(2.4,Z)]},"shovel":{"rotation":[(0,Z),(.5,[-40,0,0]),(.7,[-45,0,0]),(1.2,[-10,0,0]),(1.7,[40,60,0]),(2.4,Z)]},
 "arm_right":{"rotation":[(0,Z),(.5,[30,0,10]),(1.2,[-20,0,10]),(1.7,[-50,0,30]),(2.4,Z)]},"root":{"position":[(0,Z),(.5,[0,-1.5,0]),(.7,[0,-2,0]),(1.2,[0,.5,0]),(2.4,Z)]},"leg_left":{"rotation":[(0,Z),(.6,[-25,0,0]),(1.2,Z),(2.4,Z)]},"leg_right":{"rotation":[(0,Z),(.6,[20,0,0]),(1.2,Z),(2.4,Z)]}}))
# SHOVEL SWING 1.3s: two-handed overhead chop
m.animation("shovel_swing",1.3,False,merge({"body":{"rotation":[(0,Z),(.4,[25,-15,0]),(.6,[-25,10,0]),(.9,[-20,8,0]),(1.3,Z)]},"head":{"rotation":[(0,Z),(.4,[-20,0,0]),(.6,[15,0,0]),(1.3,Z)]},
 "arm_left":{"rotation":[(0,Z),(.4,[-140,0,-10]),(.6,[30,0,0]),(.9,[25,0,0]),(1.3,Z)]},"forearm_left":{"rotation":[(0,Z),(.4,[10,0,0]),(.6,[40,0,0]),(1.3,Z)]},"shovel":{"rotation":[(0,Z),(.4,[-20,0,0]),(.6,[-40,0,0]),(.9,[-40,0,0]),(1.3,Z)]},
 "arm_right":{"rotation":[(0,Z),(.4,[-120,0,20]),(.6,[20,0,10]),(1.3,Z)]},"root":{"position":[(0,Z),(.4,[0,1.5,1]),(.6,[0,-1.5,-3]),(1.3,Z)]},"leg_left":{"rotation":[(0,Z),(.6,[-20,0,0]),(1.3,Z)]},"leg_right":{"rotation":[(0,Z),(.6,[15,0,0]),(1.3,Z)]},"jaw":{"rotation":[(0,Z),(.4,[-30,0,0]),(.7,Z),(1.3,Z)]},"hat":{"rotation":[(0,Z),(.4,[-10,0,0]),(.65,[15,0,0]),(.9,[-5,0,0]),(1.3,Z)]}}))
# LANTERN RAISE 2s: lifts lantern high, peers around, wisps flare
m.animation("lantern_raise",2,False,merge({"arm_right":{"rotation":[(0,Z),(.5,[-110,0,20]),(1.5,[-115,0,20]),(2,Z)]},"forearm_right":{"rotation":[(0,Z),(.5,[30,0,0]),(1.5,[30,0,0]),(2,Z)]},"lantern":{"rotation":[(0,Z),(.5,[70,0,-10]),(1.5,[70,0,-10]),(2,Z)]},
 "body":{"rotation":[(0,Z),(.5,[12,-15,0]),(1.0,[12,15,0]),(1.5,[12,-10,0]),(2,Z)]},"head":{"rotation":[(0,Z),(.5,[-10,-30,0]),(1.0,[-10,30,0]),(1.5,[-8,-15,0]),(2,Z)]}},
 {b:{"position":[(0,Z),(.5,[0,3,0]),(1.0,[math.cos(i*2)*4,4,math.sin(i*2)*4]),(1.5,[math.cos(i*2)*4,3,math.sin(i*2)*4]),(2,Z)]} for i,b in enumerate(wisps)}))
# RISE 4s: from a crouch/grave, straightens with creaks
m.animation("rise",4,False,merge({"root":{"position":[(0,[0,-14,0],L),(.8,[0,-14,0]),(1.4,[0,-13,0]),(1.6,[0,-13.5,0]),(2.4,[0,-6,0]),(2.7,[0,-6.5,0]),(3.4,[0,.8,0]),(4,Z)]},"body":{"rotation":[(0,[-50,0,0],L),(1.4,[-50,0,0]),(2.4,[-35,0,-6]),(3.0,[-10,0,4]),(3.5,[5,0,0]),(4,Z)]},
 "head":{"rotation":[(0,[-30,0,0],L),(1.4,[-30,0,0]),(1.9,[-20,25,0]),(2.4,[-15,-25,0]),(3.0,[5,0,0]),(4,Z)]},"arm_left":{"rotation":[(0,[30,0,0],L),(1.4,[30,0,0]),(2.0,[40,0,-10]),(3.0,[-10,0,-5]),(4,Z)]},"shovel":{"rotation":[(0,[-30,0,0],L),(1.4,[-30,0,0]),(2.4,[-10,0,0]),(4,Z)]},
 "arm_right":{"rotation":[(0,[40,0,0],L),(1.4,[40,0,0]),(2.4,[-40,0,20]),(3.2,[-20,0,10]),(4,Z)]},"leg_left":{"rotation":[(0,[-60,0,0],L),(2.4,[-60,0,0]),(3.2,[-20,0,0]),(4,Z)]},"leg_right":{"rotation":[(0,[-60,0,0],L),(2.4,[-60,0,0]),(3.4,[-15,0,0]),(4,Z)]},"hat":{"rotation":[(0,[15,0,0],L),(2.4,[15,0,0]),(3.2,[-8,0,0]),(4,Z)]},"jaw":{"rotation":[(0,Z),(2.6,[-20,0,0]),(3.2,Z),(4,Z)]}},
 {b:{"position":[(0,[0,-6,0],L),(2,[0,-4,0]),(3.4,[0,2,0]),(4,Z)]} for b in wisps}))
m.animation("death",2.5,False,merge({"root":{"position":[(0,Z),(.5,[1,0,0]),(1.0,[-1,-3,0]),(1.6,[0,-9,-2]),(1.75,[0,-8.5,-2]),(1.9,[0,-9,-2]),(2.5,[0,-9,-2],L)],"rotation":[(0,Z),(1.0,[-10,0,8]),(1.6,[-80,0,12]),(2.5,[-80,0,12],L)]},
 "body":{"rotation":[(0,Z),(.5,[-10,0,0]),(1.6,[15,0,0]),(2.5,[15,0,0],L)]},"head":{"rotation":[(0,Z),(.5,[-20,20,0]),(1.6,[-25,-30,25]),(2.5,[-25,-30,25],L)]},"hat":{"rotation":[(0,Z),(1.0,Z),(1.6,[60,0,40]),(2.5,[60,0,40],L)],"position":[(0,Z),(1.0,Z),(1.6,[3,-4,-8]),(2.5,[3,-4,-8],L)]},
 "arm_left":{"rotation":[(0,Z),(1.6,[50,0,-40]),(2.5,[50,0,-40],L)]},"shovel":{"rotation":[(0,Z),(1.0,Z),(1.4,[80,0,30]),(2.5,[80,0,30],L)],"position":[(0,Z),(1.0,Z),(1.5,[4,-8,-6]),(2.5,[4,-8,-6],L)]},"arm_right":{"rotation":[(0,Z),(1.6,[40,0,40]),(2.5,[40,0,40],L)]},"lantern":{"rotation":[(0,Z),(1.0,Z),(1.6,[-60,0,-60]),(2.5,[-60,0,-60],L)],"position":[(0,Z),(1.0,Z),(1.7,[-3,-4,-4]),(2.5,[-3,-4,-4],L)]},
 "leg_left":{"rotation":[(0,Z),(1.0,[-70,0,0]),(1.6,[-90,0,-8]),(2.5,[-90,0,-8],L)]},"leg_right":{"rotation":[(0,Z),(1.0,[-70,0,0]),(1.6,[-90,0,10]),(2.5,[-90,0,10],L)]}},
 {b:{"position":[(0,Z),(1.4,Z),(2.5,[math.cos(i*2)*6,14,math.sin(i*2)*6],L)],"scale":[(0,[1,1,1],L),(1.6,[1,1,1],L),(2.5,[.05,.05,.05],L)]} for i,b in enumerate(wisps)}))
m.save("trio/gravedigger.bbmodel"); m.save_bedrock_animation("trio/gravedigger.animation.json"); print("gravedigger",len(m.elements),[a["name"] for a in m.animations])
