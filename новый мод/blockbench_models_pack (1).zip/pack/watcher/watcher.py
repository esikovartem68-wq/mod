import sys, math, json, random
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge, wave
import pixelart as px
random.seed(11)
W,FR=128,12
tex=Texture(W,W,FR,name="watcher",frame_time=4,interpolate=False)
R={"cloth":(0,0,32,32),"jacket":(32,0,64,64),"skin":(64,0,96,32),"face":(96,0,128,32),"eye":(64,32,96,64),"eye_big":(96,32,128,64),"hair":(0,64,32,96),"leather":(32,64,64,96),"shoe":(64,64,96,96),"demon":(96,64,128,96),"horn":(0,96,32,128),"claw":(32,96,64,128),"mist":(64,96,96,128),"eye_small":(96,96,128,128),"face_demon":(0,32,32,64)}
for k,r in R.items(): tex.region(k,*r)
base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda k,im: base.paste(im,R[k][:2])
def blk(w,h,b,var,seed,bands=False): return px.noise_tile(w,h,b,var=var,bevel=False,bands=bands,seed=seed)
c=blk(32,32,(22,22,26),8,1); d=ImageDraw.Draw(c)
for y in range(0,32,3): d.line([0,y,31,y],fill=(16,16,19,255))
put("cloth",c)
j=blk(32,64,(14,14,17),7,2); d=ImageDraw.Draw(j)
for _ in range(60): x,y=random.randint(0,30),random.randint(0,62); d.line([x,y,x+1,y+random.randint(2,5)],fill=(30,30,34,255))   # creases
d.line([15,0,15,63],fill=(6,6,8,255)); d.line([17,0,17,63],fill=(6,6,8,255))
for y in range(6,60,8): d.rectangle([15,y,17,y+1],fill=(40,40,44,255))   # zipper
put("jacket",j)
put("skin",blk(32,32,(10,10,12),5,3))
f=blk(32,32,(10,10,12),5,4); d=ImageDraw.Draw(f)
for cx in (10,21): d.ellipse([cx-5,10,cx+5,18],fill=(245,245,250,255)); d.ellipse([cx-2,12,cx+2,16],fill=(10,10,12,255))
d.line([13,25,18,25],fill=(30,30,34,255)); put("face",f)
h=blk(32,32,(6,6,8),4,5); d=ImageDraw.Draw(h)
for x in range(0,32,2): d.line([x,0,x+random.randint(-1,1),31],fill=(16,16,20,255))
put("hair",h)
le=blk(32,32,(18,16,16),6,6,bands=True); put("leather",le); put("shoe",blk(32,32,(8,8,10),4,7))
dm=blk(32,32,(12,10,14),8,8); d=ImageDraw.Draw(dm)
for _ in range(40): x,y=random.randint(0,30),random.randint(0,30); d.line([x,y,x+random.randint(-3,3),y+random.randint(-3,3)],fill=(36,30,40,255))
for _ in range(15): x,y=random.randint(0,30),random.randint(0,30); d.point((x,y),fill=(200,200,210,255))
put("demon",dm); put("horn",blk(32,32,(20,20,24),6,9,bands=True)); put("claw",blk(32,32,(30,30,34),8,10))
put("mist",Image.new("RGBA",(32,32),(0,0,0,0))); put("eye",Image.new("RGBA",(32,32),(0,0,0,0))); put("eye_big",Image.new("RGBA",(32,32),(0,0,0,0))); put("eye_small",Image.new("RGBA",(32,32),(0,0,0,0)))
def eyeball(d,x0,y0,s,look,blink,pupil=.34,veins=False,creepy=False):
    cx,cy=x0+s/2,y0+s/2
    if blink: d.rectangle([x0,int(cy)-1,x0+s,int(cy)+1],fill=(235,235,240,255)); return
    d.ellipse([x0,y0,x0+s,y0+s],fill=(240,240,245,255))
    d.ellipse([x0,y0,x0+s,y0+s],outline=(150,150,160,255))
    if veins:
        for i in range(6):
            a=i*1.05+0.3; d.line([cx+math.cos(a)*s*.48,cy+math.sin(a)*s*.48,cx+math.cos(a+.4)*s*.22,cy+math.sin(a+.4)*s*.22],fill=(120,120,130,255))
    r=max(1,int(s*pupil/2)); px_,py_=int(cx+look[0]*(s/2-r-2)),int(cy+look[1]*(s/2-r-2))
    d.ellipse([px_-r-1,py_-r-1,px_+r+1,py_+r+1],fill=(90,90,100,255))   # iris ring (grey)
    if creepy: d.rectangle([px_-max(1,r//3),py_-r,px_+max(1,r//3),py_+r],fill=(6,6,8,255))  # slit pupil
    else: d.ellipse([px_-r,py_-r,px_+r,py_+r],fill=(6,6,8,255))
    d.point((px_-r//2,py_-r//2),fill=(255,255,255,255))
def calm_face(d,fx,fy,blink):
    # human: two crisp white eyes, straight, still pupils; rare blink
    for cx in (10,21):
        if blink: d.rectangle([fx+cx-5,fy+11,fx+cx+5,fy+17],fill=(10,10,12,255)); d.line([fx+cx-4,fy+14,fx+cx+4,fy+14],fill=(235,235,240,255))
        else:
            d.rectangle([fx+cx-5,fy+11,fx+cx+5,fy+17],fill=(240,240,245,255)); d.rectangle([fx+cx-5,fy+11,fx+cx+5,fy+11],fill=(190,190,200,255))
            d.rectangle([fx+cx-1,fy+13,fx+cx+1,fy+16],fill=(6,6,8,255)); d.point((fx+cx-1,fy+13),fill=(255,255,255,255))
    d.line([fx+13,fy+25,fx+18,fy+25],fill=(30,30,34,255))
def demon_face(d,fx,fy,t,fi):
    d.rectangle([fx,fy,fx+31,fy+31],fill=(8,8,10,255))
    for i in range(14):   # white cracks
        x,y=(i*9)%30,(i*13)%30; d.line([fx+x,fy+y,fx+x+random.choice([-3,3]),fy+y+random.randint(2,5)],fill=(90,90,100,255))
    look=(math.sin(t*4)*.8,math.cos(t*3.1)*.5); jitter=int(math.sin(t*9))
    d.ellipse([fx+3,fy+6,fx+15,fy+18],fill=(245,245,250,255)); d.ellipse([fx+17,fy+5,fx+29,fy+17],fill=(245,245,250,255))   # huge uneven eyes
    for cx,cy in ((9,12),(23,11)):
        for a in range(0,360,45): d.line([fx+cx+math.cos(math.radians(a))*6,fy+cy+math.sin(math.radians(a))*6,fx+cx+math.cos(math.radians(a))*3,fy+cy+math.sin(math.radians(a))*3],fill=(150,150,160,255))
        px_,py_=fx+cx+int(look[0]*3)+jitter,fy+cy+int(look[1]*3); d.rectangle([px_,py_-2,px_,py_+2],fill=(0,0,0,255))  # pin slit pupils
    d.ellipse([fx+13,fy+1,fx+19,fy+7],fill=(245,245,250,255)); d.point((fx+16,fy+4),fill=(0,0,0,255))   # third small eye on brow
    # torn grin
    d.polygon([(fx+3,fy+22),(fx+29,fy+21),(fx+27,fy+29),(fx+5,fy+30)],fill=(25,6,10,255))
    for x in range(4,29,3): d.polygon([(fx+x,fy+22),(fx+x+2,fy+22),(fx+x+1,fy+26)],fill=(235,230,225,255)); d.polygon([(fx+x+1,fy+29),(fx+x+3,fy+29),(fx+x+2,fy+25)],fill=(215,210,205,255))
def paint(fr,fi,t):
    d=ImageDraw.Draw(fr); blink=(fi==10)
    ex,ey=R["eye"][:2]; eyeball(d,ex+3,ey+3,25,(0,0),blink)                       # human eye cubes: still
    fx,fy=R["face"][:2]; calm_face(d,fx,fy,blink)
    random.seed(99); demon_face(d,*R["face_demon"][:2],t,fi)
    look=(math.sin(t*2.6),math.cos(t*1.9)*.7)
    bx,by=R["eye_big"][:2]; eyeball(d,bx+2,by+2,27,look,fi==4,.3,veins=True,creepy=True)
    sx,sy=R["eye_small"][:2]
    for i,(ox,oy) in enumerate(((2,2),(17,2),(2,17),(17,17))): eyeball(d,sx+ox,sy+oy,12,(math.sin(t*2+i*1.7),math.cos(t*2.4+i)),(fi+i*3)%12==0,.4,creepy=(i%2==0))
    mx,my=R["mist"][:2]
    for i in range(24):
        x=(i*13+fi*2)%32; y=(i*7+fi*3)%32; a=int(90+80*math.sin(t*2+i)); d.rectangle([mx+x,my+y,mx+x+2,my+y+2],fill=(20,18,26,a))
strip=px.make_strip(base,FR,paint); tex.set_image(strip); strip.save("watcher/watcher.png"); json.dump(tex.mcmeta(),open("watcher/watcher.png.mcmeta","w"))

m=Model("watcher",tex,fmt="free",seed=9)
m.bone("root",[0,0,0]); m.bone("body",[0,12,0],"root"); m.bone("chest",[0,18,0],"body"); m.bone("head",[0,24,0],"chest"); m.bone("hair",[0,32,0],"head"); m.bone("collar",[0,24,0],"chest")
m.bone("arm_left",[5,22,0],"chest"); m.bone("fore_left",[6,16,0],"arm_left"); m.bone("arm_right",[-5,22,0],"chest"); m.bone("fore_right",[-6,16,0],"arm_right")
m.bone("leg_left",[2,12,0],"root"); m.bone("leg_right",[-2,12,0],"root")
# demon parts (hidden at rest: scale 0)
m.bone("demon",[0,18,0],"chest"); m.bone("horns",[0,32,0],"head")
D=[]  # demon arms: 2 pairs (upper-back, lower-side) + originals become 6 total
for i,(sgn,y,name) in enumerate(((1,24,"darm_l1"),(-1,24,"darm_r1"),(1,19,"darm_l2"),(-1,19,"darm_r2"))):
    m.bone(name,[sgn*5,y,1.5],"demon"); m.bone(name+"_f",[sgn*7,y-6,1.5],name); D.append((sgn,y,name))
m.bone("eyes",[0,20,0],"root")
NE=14
for i in range(NE): m.bone(f"eye_{i}",[0,20,0],"eyes")
m.bone("third_eye",[0,29,-4.2],"head"); m.bone("demon_face",[0,28,-4],"head"); m.bone("chest_eye",[0,20,-2.5],"chest")
# --- humanoid
m.cube("hips",[-4,12,-2],[4,18,2],"cloth","body"); m.cube("torso",[-4.5,18,-2.5],[4.5,24,2.5],"jacket","chest"); m.cube("torso_low",[-4.6,15,-2.6],[4.6,18.5,2.6],"jacket","body")
m.cube("collar",[-5,23.5,-3],[5,25.5,3],"leather","collar"); m.cube("hood",[-5.5,24.5,0],[5.5,30,3.8],"jacket","chest",rot=[-10,0,0],origin=[0,24.5,2])
m.cube("head",[-4,24,-4],[4,32,4],"skin","head",faces={"north":"face"}); m.cube("hair",[-4.5,29,-4.5],[4.5,33,4.5],"hair","hair"); m.cube("hair_front",[-4.5,28,-4.8],[-1,31,-4.2],"hair","hair"); m.cube("hair_back",[-4.5,25,4],[4.5,32,5],"hair","hair")
m.cube("eye_l",[-3.5,27,-4.5],[-.8,29,-3.9],"eye","head",full=True); m.cube("eye_r",[.8,27,-4.5],[3.5,29,-3.9],"eye","head",full=True)
for sgn,a,f in ((1,"arm_left","fore_left"),(-1,"arm_right","fore_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(4.5,8.5); m.cube(f"sleeve_{a}",[xa,16,-2],[xb,24,2],"jacket",a); xa,xb=X(4.7,8.3); m.cube(f"fore_{a}",[xa,10,-1.8],[xb,16.5,1.8],"jacket",f); xa,xb=X(5,8); m.cube(f"hand_{a}",[xa,7,-1.5],[xb,10,1.5],"skin",f)
for sgn,l in ((1,"leg_left"),(-1,"leg_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(0,4); m.cube(f"leg_{l}",[xa,1.5,-2],[xb,12,2],"cloth",l); xa,xb=X(-.2,4.2); m.cube(f"shoe_{l}",[xa,0,-3],[xb,2,2.2],"shoe",l)
# --- demon extras
for sgn,y,name in D:
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(4.6,7.6); m.cube(f"{name}_up",[xa,y-6,0],[xb,y,3],"demon",name); xa,xb=X(4.8,7.4); m.cube(f"{name}_fore",[xa,y-13,.2],[xb,y-5.5,2.8],"demon",name+"_f")
    for k in range(3): xa,xb=X(5+k*.8,5.6+k*.8); m.cube(f"{name}_claw{k}",[xa,y-17,.5],[xb,y-13,1.3],"claw",name+"_f",rot=[-10+k*8,0,0],origin=[(xa+xb)/2,y-13,.9])
for sgn in (1,-1):
    m.cube(f"horn_{sgn}",[min(sgn*2,sgn*4),32,-1],[max(sgn*2,sgn*4),40,1],"horn","horns",rot=[-15,0,sgn*-25],origin=[sgn*3,32,0]); m.cube(f"horn2_{sgn}",[min(sgn*2.3,sgn*3.7),38.5,-.7],[max(sgn*2.3,sgn*3.7),44,.7],"horn","horns",rot=[-35,0,sgn*-45],origin=[sgn*3,38.5,0])
m.cube("demon_face",[-4.1,23.9,-4.9],[4.1,32.1,-4.3],"face_demon","demon_face",full=True,faces={"north":"face_demon","east":"skin","west":"skin","up":"skin","down":"skin","south":"skin"}); m.cube("chest_eye",[-2,18.5,-2.9],[2,22,-2.4],"eye_big","chest_eye",full=True)
for i in range(NE):
    a=i*2.4; r=8+(i%3)*4; y=8+i*2.2; s=(2,3,1.5)[i%3]; mat=("eye_small","eye_big","eye")[i%3]
    x,z=math.cos(a)*r,math.sin(a)*r
    m.cube(f"eye_{i}",[x-s,y-s,z-s*.3],[x+s,y+s,z+s*.3],mat,f"eye_{i}",full=True,rot=[0,math.degrees(-a)-90,0],origin=[x,y,z])
    m.cube(f"eye_{i}_mist",[x-s-.6,y-s-.6,z-s*.3-.3],[x+s+.6,y+s+.6,z+s*.3+.3],"mist",f"eye_{i}",full=True,rot=[0,math.degrees(-a)-90,0],origin=[x,y,z])
ARM=lambda b: b.startswith(("arm_","fore_","darm_"))
_orig_anim=m.animation
def _anim(name,length,loop,tracks):
    fixed={}
    for b,ch in tracks.items():
        if ARM(b) and "rotation" in ch:
            ch=dict(ch); ch["rotation"]=[(k[0],[-k[1][0],k[1][1],k[1][2]])+tuple(k[2:]) for k in ch["rotation"]]
        fixed[b]=ch
    return _orig_anim(name,length,loop,fixed)
m.animation=_anim
Z=[0,0,0]; L="linear"; S0=[0,0,0]; S1=[1,1,1]; eyes=[f"eye_{i}" for i in range(NE)]; darms=[n for _,_,n in D]; dfs=[n+"_f" for n in darms]
HID={b:{"scale":[(0,S0)]} for b in ["demon","horns","demon_face","chest_eye"]+eyes}   # hidden in human anims
SHOW={b:{"scale":[(0,S1)]} for b in ["demon","horns","demon_face","chest_eye"]+eyes}
def orbit(length,rad=1,rise=0,spin=1,n=8):
    d={}
    for i,b in enumerate(eyes):
        ph=i*.9; d[b]={"position":[(length*k/n,[math.cos(2*math.pi*k/n*spin+ph)*2.5*rad,rise+math.sin(2*math.pi*k/n*2+ph)*2*rad,math.sin(2*math.pi*k/n*spin+ph)*2.5*rad]) for k in range(n+1)],"rotation":[(0,Z,L),(length,[0,360*spin,0],L)]}
    return d
def eyes_pos(v):
    return {b:{"position":[(0,Z)]}for b in eyes} if v is None else {}
# --- human anims
m.animation("idle",4,True,merge(HID,{"chest":{"rotation":[(0,Z),(2,[-2,0,0]),(4,Z)],"position":[(0,Z),(2,[0,-.3,0]),(4,Z)]},"head":{"rotation":[(0,Z),(.6,[0,30,0]),(1.8,[0,32,0],L),(2.2,[0,-25,0]),(3.4,[0,-28,0],L),(3.8,Z),(4,Z)]},
 "arm_left":{"rotation":[(0,[0,0,-2]),(2,[2,0,-3]),(4,[0,0,-2])]},"arm_right":{"rotation":[(0,[0,0,2]),(2,[2,0,3]),(4,[0,0,2])]}}))
m.animation("watch",6,True,merge(HID,{"head":{"rotation":[(0,[5,-40,0]),(2.5,[5,-40,0],L),(3.0,[5,40,0]),(5.5,[5,40,0],L),(6,[5,-40,0])]},"chest":{"rotation":[(0,[0,-10,0]),(2.5,[0,-10,0],L),(3.0,[0,10,0]),(5.5,[0,10,0],L),(6,[0,-10,0])]},
 "arm_left":{"rotation":[(0,[-70,0,-10]),(6,[-70,0,-10])]},"fore_left":{"rotation":[(0,[-40,0,-70]),(6,[-40,0,-70])]},"arm_right":{"rotation":[(0,[-70,0,10]),(6,[-70,0,10])]},"fore_right":{"rotation":[(0,[-40,0,70]),(6,[-40,0,70])]}}))   # arms crossed, head snaps
m.animation("walk",1.2,True,merge(HID,{"root":{"position":[(0,Z),(.3,[0,.6,0]),(.6,Z),(.9,[0,.6,0]),(1.2,Z)]},"body":{"rotation":[(0,[0,4,0]),(.6,[0,-4,0]),(1.2,[0,4,0])]},"head":{"rotation":[(0,[3,-4,0]),(.6,[3,4,0]),(1.2,[3,-4,0])]},
 "leg_left":{"rotation":[(0,[35,0,0]),(.6,[-35,0,0]),(1.2,[35,0,0])]},"leg_right":{"rotation":[(0,[-35,0,0]),(.6,[35,0,0]),(1.2,[-35,0,0])]},"arm_left":{"rotation":[(0,[-25,0,0]),(.6,[25,0,0]),(1.2,[-25,0,0])]},"arm_right":{"rotation":[(0,[25,0,0]),(.6,[-25,0,0]),(1.2,[25,0,0])]},"fore_left":{"rotation":[(0,[-10,0,0]),(.6,[-20,0,0]),(1.2,[-10,0,0])]},"fore_right":{"rotation":[(0,[-20,0,0]),(.6,[-10,0,0]),(1.2,[-20,0,0])]}}))
m.animation("point",1.5,False,merge(HID,{"arm_right":{"rotation":[(0,Z),(.4,[-95,0,5]),(1.1,[-95,0,5]),(1.5,Z)]},"fore_right":{"rotation":[(0,Z),(.4,[-5,0,0]),(1.5,Z)]},"head":{"rotation":[(0,Z),(.4,[-5,0,0]),(1.1,[-5,0,0]),(1.5,Z)]},"chest":{"rotation":[(0,Z),(.4,[0,-12,0]),(1.1,[0,-12,0]),(1.5,Z)]}}))
# --- TRANSFORM 4s: human -> demon
T={"root":{"position":[(0,Z),(1.0,[0,-2,0]),(1.6,[0,6,0]),(2.2,[0,2,0]),(4,[0,2,0])],"scale":[(0,S1),(1.2,S1),(2.2,[1.25,1.35,1.25]),(4,[1.25,1.35,1.25])]},
 "body":{"rotation":[(0,Z),(1.0,[25,0,0]),(1.4,[35,0,0]),(1.8,[-25,0,0]),(2.4,[-10,0,0]),(4,[-10,0,0])]},"chest":{"rotation":[(0,Z),(1.0,[20,0,0]),(1.8,[-25,0,0]),(2.4,[-8,0,0]),(4,[-8,0,0])],"scale":[(0,S1),(1.4,[1.1,1,1.1]),(1.8,[1.3,1.1,1.2]),(4,[1.3,1.1,1.2])]},
 "head":{"rotation":[(0,Z),(.6,[20,0,0]),(1.2,[30,0,15]),(1.5,[30,0,-15]),(1.8,[-45,0,0]),(2.4,[-15,0,0]),(4,[-15,0,0])]},
 "arm_left":{"rotation":[(0,Z),(1.0,[30,0,-15]),(1.4,[40,0,-25]),(1.8,[-140,0,-50]),(2.4,[-100,0,-40]),(4,[-100,0,-40])]},"arm_right":{"rotation":[(0,Z),(1.0,[30,0,15]),(1.4,[40,0,25]),(1.8,[-140,0,50]),(2.4,[-100,0,40]),(4,[-100,0,40])]},
 "fore_left":{"rotation":[(0,Z),(1.0,[-60,0,0]),(1.8,[-30,0,0]),(4,[-40,0,0])]},"fore_right":{"rotation":[(0,Z),(1.0,[-60,0,0]),(1.8,[-30,0,0]),(4,[-40,0,0])]},
 "leg_left":{"rotation":[(0,Z),(1.0,[-20,0,-8]),(1.8,[-10,0,-10]),(4,[-10,0,-10])]},"leg_right":{"rotation":[(0,Z),(1.0,[-20,0,8]),(1.8,[-10,0,10]),(4,[-10,0,10])]},
 "demon":{"scale":[(0,S0,L),(1.5,S0,L),(1.7,[.3,.3,.3]),(2.1,[1.15,1.15,1.15]),(2.4,S1),(4,S1)]},"horns":{"scale":[(0,S0,L),(1.6,S0,L),(1.7,[1,.1,1]),(2.4,S1),(4,S1)]},"demon_face":{"scale":[(0,S0,L),(1.3,S0,L),(1.32,S1,L),(4,S1)]},"chest_eye":{"scale":[(0,S0,L),(1.4,S0,L),(1.6,[1.4,1.4,1]),(1.9,S1),(4,S1)]},
 "hair":{"scale":[(0,S1),(1.5,S1),(1.8,[1,1.6,1]),(2.4,[1,1.3,1]),(4,[1,1.3,1])]}}
for i,n in enumerate(darms):
    sgn=1 if "_l" in n else -1; up=("1" in n)
    T[n]={"rotation":[(0,Z),(1.5,Z),(1.8,[-150 if up else -60,0,sgn*-60]),(2.4,[-120 if up else -30,0,sgn*(-50 if up else -35)]),(3.2,[-110 if up else -25,0,sgn*(-55 if up else -40)]),(4,[-120 if up else -30,0,sgn*(-50 if up else -35)])]}
    T[n+"_f"]={"rotation":[(0,Z),(1.5,Z),(1.8,[-60,0,0]),(2.4,[-30,0,0]),(4,[-35,0,0])]}
for i,b in enumerate(eyes):
    t0=1.4+i*.06; ph=i*.9
    T[b]={"scale":[(0,S0,L),(t0,S0,L),(t0+.25,[1.5,1.5,1.5]),(t0+.5,S1),(4,S1)],"position":[(0,[0,-6,0]),(t0,[0,-6,0]),(t0+.5,[math.cos(ph)*3,2,math.sin(ph)*3]),(4,[math.cos(ph+1)*2.5,1,math.sin(ph+1)*2.5])],"rotation":[(0,Z,L),(t0,Z,L),(4,[0,180,0],L)]}
m.animation("transform",4,False,T)
# --- demon anims
DP={"root":{"position":[(0,[0,2,0])],"scale":[(0,[1.25,1.35,1.25])]},"body":{"rotation":[(0,[-10,0,0])]},"chest":{"rotation":[(0,[-8,0,0])],"scale":[(0,[1.3,1.1,1.2])]},"head":{"rotation":[(0,[-15,0,0])]},"hair":{"scale":[(0,[1,1.3,1])]},
 "arm_left":{"rotation":[(0,[-100,0,-40])]},"arm_right":{"rotation":[(0,[-100,0,40])]},"fore_left":{"rotation":[(0,[-40,0,0])]},"fore_right":{"rotation":[(0,[-40,0,0])]},"leg_left":{"rotation":[(0,[-10,0,-10])]},"leg_right":{"rotation":[(0,[-10,0,10])]}}
for n in darms:
    sgn=1 if "_l" in n else -1; up=("1" in n); DP[n]={"rotation":[(0,[-120 if up else -30,0,sgn*(-50 if up else -35)])]}; DP[n+"_f"]={"rotation":[(0,[-35,0,0])]}
def dpose(length,extra):  # demon base pose + overrides, with hover & orbit
    base={k:{ch:[(0,v[0][1]),(length,v[0][1])] for ch,v in d.items()} for k,d in DP.items()}
    return merge(SHOW,base,orbit(length,1,1.5,1),extra)
m.animation("demon_idle",5,True,dpose(5,{"root":{"position":[(0,[0,2,0]),(2.5,[0,5,0]),(5,[0,2,0])]},"head":{"rotation":[(0,[-15,0,0]),(1.5,[-15,25,5]),(3.5,[-15,-25,-5]),(5,[-15,0,0])]},
 "chest":{"rotation":[(0,[-8,0,0]),(2.5,[-12,0,0]),(5,[-8,0,0])]},"darm_l1":{"rotation":[(0,[-120,0,-50]),(2.5,[-130,0,-60]),(5,[-120,0,-50])]},"darm_r1":{"rotation":[(0,[-120,0,50]),(2.5,[-130,0,60]),(5,[-120,0,50])]},
 "darm_l2":{"rotation":[(0,[-30,0,-35]),(2.5,[-45,0,-25]),(5,[-30,0,-35])]},"darm_r2":{"rotation":[(0,[-30,0,35]),(2.5,[-45,0,25]),(5,[-30,0,35])]},"arm_left":{"rotation":[(0,[-100,0,-40]),(2.5,[-90,0,-50]),(5,[-100,0,-40])]},"arm_right":{"rotation":[(0,[-100,0,40]),(2.5,[-90,0,50]),(5,[-100,0,40])]},
 "leg_left":{"rotation":[(0,[-10,0,-10]),(2.5,[-25,0,-12]),(5,[-10,0,-10])]},"leg_right":{"rotation":[(0,[-10,0,10]),(2.5,[-25,0,12]),(5,[-10,0,10])]}}))
m.animation("demon_gaze",3,True,dpose(3,merge(orbit(3,2.2,3,2),{"head":{"rotation":[(0,[-25,0,0]),(3,[-25,0,0])],"scale":[(0,S1),(1.5,[1.1,1.1,1.1]),(3,S1)]},"chest_eye":{"scale":[(0,S1),(1.5,[1.6,1.6,1]),(3,S1)]},
 "darm_l1":{"rotation":[(0,[-160,0,-30]),(3,[-160,0,-30])]},"darm_r1":{"rotation":[(0,[-160,0,30]),(3,[-160,0,30])]},"arm_left":{"rotation":[(0,[-90,0,-70]),(3,[-90,0,-70])]},"arm_right":{"rotation":[(0,[-90,0,70]),(3,[-90,0,70])]},"darm_l2":{"rotation":[(0,[-60,0,-60]),(3,[-60,0,-60])]},"darm_r2":{"rotation":[(0,[-60,0,60]),(3,[-60,0,60])]}})))
m.animation("demon_slash",1.6,False,dpose(1.6,{"chest":{"rotation":[(0,[-8,0,0]),(.4,[-15,35,0]),(.7,[-20,-35,0]),(1.0,[-15,30,0]),(1.6,[-8,0,0])]},"head":{"rotation":[(0,[-15,0,0]),(.4,[-15,-25,0]),(.7,[-10,25,0]),(1.6,[-15,0,0])]},
 "darm_l1":{"rotation":[(0,[-120,0,-50]),(.4,[-170,0,-70]),(.7,[-40,0,20]),(1.0,[-50,0,10]),(1.6,[-120,0,-50])]},"darm_r1":{"rotation":[(0,[-120,0,50]),(.5,[-170,0,70]),(.85,[-40,0,-20]),(1.6,[-120,0,50])]},"arm_left":{"rotation":[(0,[-100,0,-40]),(.6,[-160,0,-60]),(.95,[-30,0,10]),(1.6,[-100,0,-40])]},"arm_right":{"rotation":[(0,[-100,0,40]),(.7,[-160,0,60]),(1.05,[-30,0,-10]),(1.6,[-100,0,40])]},
 "darm_l2":{"rotation":[(0,[-30,0,-35]),(.8,[-120,0,-50]),(1.15,[-10,0,20]),(1.6,[-30,0,-35])]},"darm_r2":{"rotation":[(0,[-30,0,35]),(.9,[-120,0,50]),(1.25,[-10,0,-20]),(1.6,[-30,0,35])]},"root":{"position":[(0,[0,2,0]),(.4,[0,4,3]),(.7,[0,1,-4]),(1.6,[0,2,0])]}}))
m.animation("demon_scream",2.5,False,dpose(2.5,merge({b:{"position":[(0,Z),(.6,[math.cos(i)*10,6,math.sin(i)*10]),(1.8,[math.cos(i+1)*10,5,math.sin(i+1)*10]),(2.5,Z)],"scale":[(0,S1),(.6,[1.6,1.6,1.6]),(1.8,[1.6,1.6,1.6]),(2.5,S1)]} for i,b in enumerate(eyes)},
 {"head":{"rotation":[(0,[-15,0,0]),(.5,[-50,0,0]),(.7,[-50,0,6]),(.9,[-50,0,-6]),(1.1,[-50,0,6]),(1.3,[-50,0,-6]),(1.8,[-50,0,0]),(2.5,[-15,0,0])]},"chest":{"rotation":[(0,[-8,0,0]),(.5,[-25,0,0]),(1.8,[-25,0,0]),(2.5,[-8,0,0])]},"root":{"position":[(0,[0,2,0]),(.5,[0,8,0]),(1.8,[0,9,0]),(2.5,[0,2,0])]},
 **{n:{"rotation":[(0,DP[n]["rotation"][0][1]),(.5,[-160,0,(1 if "_l" in n else -1)*-70]),(1.8,[-165,0,(1 if "_l" in n else -1)*-80]),(2.5,DP[n]["rotation"][0][1])]} for n in darms},
 "arm_left":{"rotation":[(0,[-100,0,-40]),(.5,[-150,0,-90]),(1.8,[-150,0,-95]),(2.5,[-100,0,-40])]},"arm_right":{"rotation":[(0,[-100,0,40]),(.5,[-150,0,90]),(1.8,[-150,0,95]),(2.5,[-100,0,40])]}})))
# REVERT 2.5s demon -> human
RV={k:{ch:[(0,v[0][1]),(1.2,v[0][1]),(2.0,Z if ch!="scale" else S1),(2.5,Z if ch!="scale" else S1)] for ch,v in d.items()} for k,d in DP.items()}
RV["root"]["position"]=[(0,[0,2,0]),(1.0,[0,6,0]),(1.6,[0,-1,0]),(1.8,[0,.5,0]),(2.5,Z)]; RV["root"]["scale"]=[(0,[1.25,1.35,1.25]),(1.2,[1.25,1.35,1.25]),(1.7,[.95,1.05,.95]),(2.0,S1),(2.5,S1)]
RV["head"]["rotation"]=[(0,[-15,0,0]),(.6,[-40,0,0]),(1.4,[35,0,0]),(2.0,[10,0,0]),(2.5,Z)]
for b in ["demon","horns","demon_face","chest_eye"]: RV[b]={"scale":[(0,S1,L),(1.0,S1,L),(1.2,[1.2,1.2,1.2]),(1.6,S0,L),(2.5,S0,L)]}
for i,b in enumerate(eyes): t0=.3+i*.05; RV[b]={"scale":[(0,S1,L),(t0,S1,L),(t0+.2,[1.6,1.6,1.6]),(t0+.45,S0,L),(2.5,S0,L)],"position":[(0,[math.cos(i*.9+1)*2.5,1,math.sin(i*.9+1)*2.5]),(t0+.45,[0,-4,0]),(2.5,[0,-4,0])]}
m.animation("revert",2.5,False,RV)
m.animation("demon_death",3,False,dpose(3,merge({"root":{"position":[(0,[0,2,0]),(.5,[0,10,0]),(1.2,[0,8,0]),(2.2,[0,-3,3]),(3,[0,-3,3],L)],"rotation":[(0,Z),(1.2,[-10,0,0]),(2.2,[80,0,20]),(3,[85,0,22],L)]},"head":{"rotation":[(0,[-15,0,0]),(.5,[-60,0,0]),(1.2,[-55,0,20]),(2.2,[30,0,30]),(3,[35,0,32],L)]},
 **{n:{"rotation":[(0,DP[n]["rotation"][0][1]),(.5,[-170,0,(1 if "_l" in n else -1)*-40]),(1.4,[-160,0,(1 if "_l" in n else -1)*-90]),(2.2,[-20,0,(1 if "_l" in n else -1)*-60]),(3,[-20,0,(1 if "_l" in n else -1)*-62],L)]} for n in darms},
 "arm_left":{"rotation":[(0,[-100,0,-40]),(.5,[-170,0,-60]),(2.2,[-40,0,-80]),(3,[-40,0,-82],L)]},"arm_right":{"rotation":[(0,[-100,0,40]),(.5,[-170,0,60]),(2.2,[-40,0,80]),(3,[-40,0,82],L)]}},
 {b:{"position":[(0,Z),(.5,[math.cos(i)*8,10,math.sin(i)*8]),(1.4,[math.cos(i)*12,14,math.sin(i)*12]),(2.2,[math.cos(i)*16,-10,math.sin(i)*16]),(3,[math.cos(i)*16,-14,math.sin(i)*16],L)],"scale":[(0,S1,L),(1.4,[1.5,1.5,1.5],L),(2.4,S0,L),(3,S0,L)]} for i,b in enumerate(eyes)},
 {"demon":{"scale":[(0,S1,L),(2.3,S1,L),(3,[1,.1,1],L)]},"horns":{"scale":[(0,S1,L),(2.6,S1,L),(3,S0,L)]},"demon_face":{"scale":[(0,S1,L),(2.2,S1,L),(2.25,S0,L)]},"chest_eye":{"scale":[(0,S1,L),(1.8,S1,L),(2.4,S0,L)]}})))
m.save("watcher/watcher.bbmodel"); m.save_bedrock_animation("watcher/watcher.animation.json"); print("watcher",len(m.elements),[a["name"] for a in m.animations])
