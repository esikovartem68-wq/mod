import sys, math, json, random
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge, chain_wave
import pixelart as px
random.seed(3)
W,FR=128,16
tex=Texture(W,W,FR,name="world_worm",frame_time=4,interpolate=True)
R={"hide":(0,0,32,64),"belly":(32,0,64,64),"plate":(64,0,96,32),"rune":(96,0,128,32),"mouth":(64,32,96,64),"teeth":(96,32,128,64),"eye":(0,64,32,96),"spike":(32,64,64,96),"ring":(64,64,96,96),"tail":(96,64,128,96),"glow":(0,96,32,128),"mand":(32,96,64,128),"dirt":(64,96,96,128),"inner":(96,96,128,128)}
for k,r in R.items(): tex.region(k,*r)
RUNES=["ᚠ","ᚢ","ᚦ","ᚨ","ᚱ","ᚲ","ᚷ","ᚹ","ᚺ","ᚾ","ᛁ","ᛃ","ᛇ","ᛈ","ᛉ","ᛊ","ᛏ","ᛒ","ᛖ","ᛗ","ᛚ","ᛜ","ᛞ","ᛟ"]
def rune_glyph(d,x,y,s,col,idx):
    # pixel runes: simple strokes, deterministic per idx
    random.seed(idx*13+7); d.line([x,y,x,y+s],fill=col,width=1)
    for _ in range(random.randint(1,3)):
        yy=y+random.randint(0,s-2); dx=random.choice([-1,1])*random.randint(2,max(2,s//2)); d.line([x,yy,x+dx,yy+random.randint(-s//2,s//2)],fill=col,width=1)
    if random.random()<.5: d.line([x,y+s//2,x+random.choice([-1,1])*(s//2),y+s//2+random.randint(-2,2)],fill=col)
def hide(w,h,seed,mono):
    if mono: im=px.noise_tile(w,h,(28,26,30),var=10,bevel=False,seed=seed); dark=(10,8,12,255); light=(230,230,235,255)
    else: im=px.noise_tile(w,h,(92,62,40),var=16,bevel=False,seed=seed); dark=(50,32,20,255); light=(140,100,64,255)
    d=ImageDraw.Draw(im); random.seed(seed)
    for y in range(0,h,8): d.line([0,y,w-1,y],fill=dark,width=2); d.line([0,y+2,w-1,y+2],fill=light)  # ring folds
    for _ in range(w*h//20): x,y=random.randint(0,w-1),random.randint(0,h-1); im.putpixel((x,y),dark if random.random()<.6 else light)
    for _ in range(w*h//200): x,y=random.randint(0,w-4),random.randint(0,h-4); d.ellipse([x,y,x+3,y+3],fill=light if not mono else (200,200,210,255)); d.point((x+1,y+1),fill=dark)  # warts
    return im
def belly(w,h,seed,mono):
    if mono: im=px.noise_tile(w,h,(210,208,205),var=10,bevel=False,seed=seed); dk=(150,150,155,255)
    else: im=px.noise_tile(w,h,(180,150,110),var=12,bevel=False,seed=seed); dk=(130,100,70,255)
    d=ImageDraw.Draw(im)
    for y in range(0,h,4): d.line([0,y,w-1,y],fill=dk)
    for y in range(2,h,4): d.line([w//2-1,y,w//2+1,y],fill=dk)
    return im
def plate(seed,mono,glow_k):
    im=px.noise_tile(32,32,(40,40,44) if mono else (70,52,38),var=12,seed=seed); d=ImageDraw.Draw(im)
    px.blotches(im,20,delta=-15,seed=seed)
    d.rectangle([1,1,30,30],outline=(160,160,165,255) if mono else (110,86,60,255)); px.draw_cracks(im,px.cracks(32,32,4,seed=seed))
    base_col=(255,255,255) if mono else (255,150,50); c=tuple(int(base_col[i]*(.35+.65*glow_k)) for i in range(3))+(255,)
    for i,(x,y) in enumerate(((7,4),(19,4),(7,18),(19,18))): rune_glyph(d,x+3,y,9,c,seed*4+i)
    return im
def runeband(seed,mono,glow_k):
    im=px.noise_tile(32,32,(20,20,24) if mono else (50,36,26),var=8,bevel=False,seed=seed); d=ImageDraw.Draw(im)
    base_col=(255,255,255) if mono else (255,140,40); c=tuple(int(base_col[i]*(.3+.7*glow_k)) for i in range(3))+(255,)
    dim=tuple(int(base_col[i]*.25) for i in range(3))+(255,)
    d.line([0,4,31,4],fill=dim); d.line([0,27,31,27],fill=dim)
    for i in range(5): rune_glyph(d,3+i*6,9,13,c,seed*7+i)
    return im
def mouth(mono): 
    im=px.noise_tile(32,32,(60,20,30) if not mono else (40,10,20),var=14,bevel=False,seed=40); d=ImageDraw.Draw(im)
    for r in range(15,2,-3): d.ellipse([16-r,16-r,16+r,16+r],outline=(30,8,14,255))
    d.ellipse([12,12,20,20],fill=(10,2,6,255)); return im
def teeth(mono):
    im=Image.new("RGBA",(32,32),(30,10,15,255)); d=ImageDraw.Draw(im)
    for x in range(0,32,4): d.polygon([(x,0),(x+4,0),(x+2,12)],fill=(225,215,190,255)); d.polygon([(x,31),(x+4,31),(x+2,19)],fill=(200,190,165,255))
    return im
def paint(mono,glow_k,fi):
    base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda k,im: base.paste(im,R[k][:2])
    put("hide",hide(32,64,1,mono)); put("belly",belly(32,64,2,mono)); put("plate",plate(3,mono,glow_k)); put("rune",runeband(4,mono,glow_k)); put("mouth",mouth(mono)); put("teeth",teeth(mono))
    E=Image.new("RGBA",(32,32),(0,0,0,0)); d=ImageDraw.Draw(E); ec=(255,255,255) if mono else (255,160,60)
    d.ellipse([2,2,29,29],fill=(20,12,10,255)); d.ellipse([7,7,24,24],fill=tuple(int(ec[i]*(.5+.5*glow_k)) for i in range(3))+(255,)); d.rectangle([14,6,17,25],fill=(5,2,2,255)); put("eye",E)
    sp=px.noise_tile(32,32,(120,110,95) if not mono else (200,200,205),var=12,seed=5); put("spike",sp)
    rg=px.noise_tile(32,32,(60,44,32) if not mono else (15,15,18),var=10,bands=True,seed=6); dr=ImageDraw.Draw(rg)
    for x in range(0,32,4): dr.line([x,0,x,31],fill=(90,70,50,255) if not mono else (120,120,125,255))
    put("ring",rg); put("tail",hide(32,32,7,mono))
    G=Image.new("RGBA",(32,32),(0,0,0,0)); dg=ImageDraw.Draw(G); gc=(255,255,255) if mono else (255,140,40); a=int(90+165*glow_k)
    dg.ellipse([2,2,29,29],fill=gc+(a//3,)); dg.ellipse([8,8,23,23],fill=gc+(a,)); dg.ellipse([12,12,19,19],fill=(255,255,240,255)); put("glow",G)
    md=px.noise_tile(32,32,(50,40,36) if not mono else (25,25,28),var=10,seed=8); dm=ImageDraw.Draw(md)
    for y in range(0,32,6): dm.line([0,y,31,y],fill=(90,75,60,255) if not mono else (150,150,155,255))
    put("mand",md); dt=px.noise_tile(32,32,(80,62,44),var=16,bevel=False,seed=9); px.speckle(dt,80,seed=9); put("dirt",dt)
    inn=px.noise_tile(32,32,(90,30,40) if not mono else (60,15,25),var=14,bevel=False,seed=10); di=ImageDraw.Draw(inn)
    for r in range(16,0,-4): di.ellipse([16-r,16-r,16+r,16+r],outline=(50,10,18,255))
    put("inner",inn); return base
frames=[]
for fi in range(FR):
    # 0-10: brown, runes slowly pulse; 11-14: black/white "attack" flash, runes blazing; 15: back to brown
    if 11<=fi<=14: mono=True; gk=1.0 if fi in (12,13) else .7
    else: mono=False; gk=.5+.5*math.sin(fi/11*2*math.pi)
    frames.append(paint(mono,gk,fi))
strip=Image.new("RGBA",(W,W*FR)); [strip.paste(f,(0,i*W)) for i,f in enumerate(frames)]
tex.set_image(strip); strip.save("worm/world_worm.png"); json.dump(tex.mcmeta(),open("worm/world_worm.png.mcmeta","w"))
paint(False,.7,0).save("worm/world_worm_brown.png"); paint(True,1,0).save("worm/world_worm_attack_bw.png")

m=Model("world_worm",tex,fmt="free",seed=5)
N=14  # body segments
m.bone("root",[0,0,0]); m.bone("head",[0,18,-20],"root")
m.bone("jaw_top",[0,30,-30],"head"); m.bone("jaw_bot",[0,8,-30],"head"); m.bone("jaw_l",[16,18,-30],"head"); m.bone("jaw_r",[-16,18,-30],"head"); m.bone("throat",[0,18,-30],"head")
for i in range(6): m.bone(f"tooth_ring_{i}",[0,18,-30],"throat")
# head cubes
m.cube("head_core",[-16,2,-30],[16,34,-4],"hide","head",faces={"down":"belly"}); m.cube("head_plate_top",[-14,33,-28],[14,38,-6],"plate","head"); m.cube("head_rune",[-17,10,-8],[17,28,-2],"rune","head")
m.cube("head_plate_l",[15,6,-26],[19,30,-8],"plate","head"); m.cube("head_plate_r",[-19,6,-26],[-15,30,-8],"plate","head")
for sgn in (1,-1):
    for i,(y,z) in enumerate(((30,-24),(30,-14),(30,-6))): m.cube(f"eye_{sgn}_{i}",[min(sgn*12,sgn*15.5),y-2,z-2],[max(sgn*12,sgn*15.5),y+2,z+2],"eye","head",full=True)
    m.cube(f"crest_{sgn}",[min(sgn*6,sgn*10),36,-20],[max(sgn*6,sgn*10),46,-8],"spike","head",rot=[-25,0,sgn*-20],origin=[sgn*8,36,-14])
    m.cube(f"crest2_{sgn}",[min(sgn*12,sgn*15),34,-14],[max(sgn*12,sgn*15),42,-4],"spike","head",rot=[-20,0,sgn*-40],origin=[sgn*13.5,34,-9])
# four-way jaws
m.cube("jaw_top_c",[-12,28,-46],[12,36,-30],"hide","jaw_top",faces={"down":"teeth"},origin=[0,30,-30]); m.cube("jaw_top_plate",[-10,35,-44],[10,39,-32],"plate","jaw_top"); m.cube("jaw_top_tip",[-8,26,-52],[8,33,-45],"spike","jaw_top",rot=[20,0,0],origin=[0,30,-46])
m.cube("jaw_bot_c",[-12,2,-46],[12,10,-30],"hide","jaw_bot",faces={"up":"teeth"}); m.cube("jaw_bot_plate",[-10,-1,-44],[10,3,-32],"plate","jaw_bot"); m.cube("jaw_bot_tip",[-8,5,-52],[8,12,-45],"spike","jaw_bot",rot=[-20,0,0],origin=[0,8,-46])
m.cube("jaw_l_c",[8,8,-46],[16,28,-30],"hide","jaw_l",faces={"west":"teeth"}); m.cube("jaw_l_plate",[16,10,-44],[19,26,-32],"plate","jaw_l"); m.cube("jaw_l_tip",[9,10,-52],[15,26,-45],"spike","jaw_l",rot=[0,-20,0],origin=[12,18,-46])
m.cube("jaw_r_c",[-16,8,-46],[-8,28,-30],"hide","jaw_r",faces={"east":"teeth"}); m.cube("jaw_r_plate",[-19,10,-44],[-16,26,-32],"plate","jaw_r"); m.cube("jaw_r_tip",[-15,10,-52],[-9,26,-45],"spike","jaw_r",rot=[0,20,0],origin=[-12,18,-46])
m.cube("throat",[-9,9,-34],[9,27,-12],"inner","throat",full=True); m.cube("throat_glow",[-4,14,-30],[4,22,-22],"glow","throat",full=True)
for i in range(6):
    a=i*60; m.cube(f"tooth_ring_{i}",[-1.5,24,-36],[1.5,30,-30],"teeth","tooth_ring_%d"%i,rot=[0,0,a],origin=[0,18,-33],full=True)
# body chain: nested bones so waves propagate
parent="root"; z=0; sizes=[16,17,17.5,17.5,17,16.5,16,15,14,12.5,11,9,7,5]
for i in range(N):
    s=sizes[i]; L=14 if i<N-2 else 12
    m.bone(f"seg_{i}",[0,18,z],parent); parent=f"seg_{i}"
    m.cube(f"seg_{i}",[-s,18-s,z],[s,18+s,z+L],"hide",f"seg_{i}",faces={"down":"belly"})
    m.cube(f"ring_{i}",[-s-1.2,18-s-1.2,z+L-3],[s+1.2,18+s+1.2,z+L],"ring",f"seg_{i}")
    if i%2==0: m.cube(f"plate_{i}",[-s*.7,18+s-1,z+1],[s*.7,18+s+3,z+L-4],"plate",f"seg_{i}")
    else: m.cube(f"runeband_{i}",[-s-.5,18-s*.4,z+2],[s+.5,18+s*.4,z+L-4],"rune",f"seg_{i}")
    if i%3==1:
        for sgn in (1,-1): m.cube(f"spike_{i}_{sgn}",[min(sgn*(s-2),sgn*(s+8)),18+s*.5,z+4],[max(sgn*(s-2),sgn*(s+8)),18+s*.5+4,z+9],"spike",f"seg_{i}",rot=[0,0,sgn*35],origin=[sgn*(s-2),18+s*.5+2,z+6])
    if i%2==0:
        for sgn in (1,-1): m.cube(f"glow_{i}_{sgn}",[min(sgn*(s+.3),sgn*(s+1.3)),16,z+5],[max(sgn*(s+.3),sgn*(s+1.3)),20,z+9],"glow",f"seg_{i}",full=True)
    for sgn in (1,-1): m.cube(f"leg_{i}_{sgn}",[min(sgn*(s*.6),sgn*(s*.6+2.5)),18-s-5,z+4],[max(sgn*(s*.6),sgn*(s*.6+2.5)),18-s+1,z+8],"spike",f"seg_{i}",rot=[0,0,sgn*20],origin=[sgn*s*.6,18-s,z+6])   # bristle-legs
    z+=L
m.bone("tail",[0,18,z],parent); m.cube("tail_cone",[-4,14,z],[4,22,z+10],"tail","tail"); m.cube("tail_spike",[-2,16,z+9],[2,20,z+20],"spike","tail"); m.cube("tail_glow",[-2.5,15.5,z+8],[2.5,20.5,z+10],"glow","tail",full=True)
m.cube("stinger_l",[2,17,z+6],[6,19,z+14],"spike","tail",rot=[0,-25,0],origin=[2,18,z+6]); m.cube("stinger_r",[-6,17,z+6],[-2,19,z+14],"spike","tail",rot=[0,25,0],origin=[-2,18,z+6])
segs=[f"seg_{i}" for i in range(N)]+["tail"]; Z=[0,0,0]; L="linear"; jaws={"jaw_top":[-1,0,0],"jaw_bot":[1,0,0],"jaw_l":[0,1,0],"jaw_r":[0,-1,0]}
def slither(length,amp_y,amp_x,cycles=1,step=.55): return merge(chain_wave(segs,length,amp_y,cycles,step,axis=1),chain_wave(segs,length,amp_x,cycles,step*1.1,axis=0))
def jaw_open(deg,t0,t1,t2,t3=None):
    d={}
    for j,ax in jaws.items():
        ks=[(0,Z),(t0,Z),(t1,[a*deg for a in ax]),(t2,[a*deg*.9 for a in ax])]
        if t3: ks.append((t3,Z))
        d[j]={"rotation":ks}
    return d
def rings(length,spin=360): return {f"tooth_ring_{i}":{"rotation":[(0,Z,L),(length,[0,0,spin*(1 if i%2 else -1)],L)]} for i in range(6)}
m.animation("idle",6,True,merge(slither(6,2.5,2),{"head":{"rotation":[(0,Z),(1.5,[-6,10,3]),(3,[4,-8,-3]),(4.5,[-3,6,0]),(6,Z)],"position":[(0,Z),(3,[0,2,0]),(6,Z)]}},
 {j:{"rotation":[(0,Z),(3,[a*6 for a in ax]),(6,Z)]} for j,ax in jaws.items()},{"throat":{"scale":[(0,[1,1,1]),(3,[1.06,1.06,1]),(6,[1,1,1])]}},rings(6,60)))
m.animation("crawl",2.4,True,merge(slither(2.4,9,5,1,.7),{"root":{"position":[(0,[0,0,0]),(1.2,[0,2,0]),(2.4,Z)]},"head":{"rotation":[(0,[-6,0,0]),(1.2,[6,0,0]),(2.4,[-6,0,0])]}},rings(2.4,120)))
# ROAR/rise: rears head up, jaws splay, rune glow (tex cycle) 3s
m.animation("roar",3,False,merge({"head":{"rotation":[(0,Z),(.8,[-55,0,0]),(1.2,[-50,8,0]),(1.8,[-52,-8,0]),(2.4,[-45,0,0]),(3,Z)],"position":[(0,Z),(.8,[0,25,10]),(2.4,[0,22,8]),(3,Z)]},
 **{f"seg_{i}":{"rotation":[(0,Z),(.8,[-max(0,22-i*4),0,0]),(2.4,[-max(0,20-i*4),0,0]),(3,Z)]} for i in range(6)}},jaw_open(45,.5,1.0,2.3,3),rings(3,720),
 {"throat":{"scale":[(0,[1,1,1]),(1.0,[1.2,1.2,1]),(1.4,[1.1,1.1,1]),(1.8,[1.25,1.25,1]),(2.3,[1.15,1.15,1]),(3,[1,1,1])]}}))
# BITE attack 1.6s: coils back, lunges forward, jaws snap
m.animation("bite",1.6,False,merge({"head":{"rotation":[(0,Z),(.45,[-30,0,0]),(.7,[25,0,0]),(.85,[20,0,0]),(1.6,Z)],"position":[(0,Z),(.45,[0,10,14]),(.7,[0,-6,-30]),(1.0,[0,-4,-26]),(1.6,Z)]},
 **{f"seg_{i}":{"rotation":[(0,Z),(.45,[-max(0,12-i*3),0,0]),(.7,[max(0,10-i*3),0,0]),(1.6,Z)],"position":[(0,Z),(.45,[0,0,max(0,6-i*2)]),(.7,[0,0,-max(0,10-i*2.5)]),(1.6,Z)]} for i in range(6)}},
 {j:{"rotation":[(0,Z),(.45,[a*55 for a in ax]),(.68,[a*50 for a in ax]),(.76,[a*-4 for a in ax],L),(.9,[a*-4 for a in ax]),(1.6,Z)]} for j,ax in jaws.items()},rings(1.6,900),
 {"throat":{"scale":[(0,[1,1,1]),(.45,[1.3,1.3,1]),(.76,[.9,.9,1]),(1.6,[1,1,1])]}}))
# TAIL_WHIP 1.8s: whole body swings sideways
m.animation("tail_whip",1.8,False,merge({f"seg_{i}":{"rotation":[(0,Z),(.6,[0,min(14,4+i*1.5),0]),(1.0,[0,-min(16,5+i*1.8),0]),(1.4,[0,4,0]),(1.8,Z)]} for i in range(N)},{"tail":{"rotation":[(0,Z),(.6,[0,20,0]),(1.0,[0,-30,0]),(1.8,Z)]},"head":{"rotation":[(0,Z),(.6,[0,-25,0]),(1.0,[0,30,0]),(1.8,Z)]}}))
# BURROW 2.5s: dives down head-first
m.animation("burrow",2.5,False,merge({"root":{"position":[(0,Z),(.6,[0,8,0]),(2.5,[0,-120,0],L)]},"head":{"rotation":[(0,Z),(.6,[-20,0,0]),(1.2,[70,0,0]),(2.5,[80,0,0],L)]},**{f"seg_{i}":{"rotation":[(0,Z),(1.2+i*.06,[0,0,0]),(2.5,[min(80,12+i*6),0,0],L)]} for i in range(N)}},jaw_open(30,.3,.8,1.2,2.0),rings(2.5,1080)))
# EMERGE 2.5s: bursts up from underground
m.animation("emerge",2.5,False,merge({"root":{"position":[(0,[0,-120,0],L),(.3,[0,-120,0],L),(1.2,[0,30,0]),(1.6,[0,-4,0]),(2.0,[0,2,0]),(2.5,Z)]},"head":{"rotation":[(0,[-70,0,0],L),(.3,[-70,0,0]),(1.2,[-60,0,0]),(1.7,[10,0,0]),(2.5,Z)]},
 **{f"seg_{i}":{"rotation":[(0,[-min(70,10+i*6),0,0],L),(.3,[-min(70,10+i*6),0,0]),(1.4,[-min(30,4+i*3),0,0]),(2.5,Z)]} for i in range(N)}},jaw_open(50,.8,1.3,1.9,2.5),rings(2.5,1080),
 {"throat":{"scale":[(0,[1,1,1]),(1.2,[1.3,1.3,1]),(1.9,[1.2,1.2,1]),(2.5,[1,1,1])]}}))
# DEATH 4s: thrashes then collapses
m.animation("death",4,False,merge({"head":{"rotation":[(0,Z),(.5,[-40,20,0]),(1.0,[-30,-25,10]),(1.5,[-45,15,-10]),(2.2,[20,0,15]),(3,[40,0,40]),(4,[40,0,45],L)],"position":[(0,Z),(.5,[0,15,5]),(1.5,[0,12,5]),(3,[0,-16,0]),(4,[0,-16,0],L)]},
 **{f"seg_{i}":{"rotation":[(0,Z),(.5,[-8,10*(1 if i%2 else -1),0]),(1.0,[6,-12*(1 if i%2 else -1),0]),(1.5,[-8,10*(1 if i%2 else -1),0]),(2.2,[3,0,0]),(3,[0,0,(1 if i%2 else -1)*6]),(4,[0,0,(1 if i%2 else -1)*6],L)],"position":[(0,Z),(3,[0,-min(4,i*.4),0]),(4,[0,-min(4,i*.4),0],L)]} for i in range(N)}},
 jaw_open(50,.2,.6,2.5,3.5),rings(4,1440),{"throat":{"scale":[(0,[1,1,1]),(.6,[1.3,1.3,1]),(3.2,[.6,.6,1]),(4,[.5,.5,1],L)]}}))
m.save("worm/world_worm.bbmodel"); m.save_bedrock_animation("worm/world_worm.animation.json"); print("worm",len(m.elements),[a["name"] for a in m.animations])
