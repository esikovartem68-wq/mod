import sys, math, json
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge, wave, hover, chain_wave
import pixelart as px
W,FR=128,8
tex=Texture(W,W,FR,name="well_monster",frame_time=3)
for k,r in {"skin":(0,0,32,64),"dskin":(32,0,64,64),"hair":(64,0,96,64),"bone":(96,0,128,32),"water":(96,32,128,64),"face":(0,64,32,96),"back":(32,64,64,96),"rag":(64,64,96,96),"eye":(96,64,128,96),"slime":(0,96,32,128),"stone":(32,96,64,128)}.items(): tex.region(k,*r)
base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda k,im: base.paste(im,tex.regions[k][:2])
s=px.noise_tile(32,64,(168,178,170),var=16,bands=True,seed=1); px.blotches(s,16,-30,seed=1); d=ImageDraw.Draw(s)
for _ in range(20): x,y=px.random.randint(0,28),px.random.randint(0,58); d.line([x,y,x+2,y+5],fill=(90,110,120,255))   # veins
put("skin",s); put("dskin",px.noise_tile(32,64,(96,108,104),var=14,seed=2))
h=px.noise_tile(32,64,(14,12,16),var=8,bevel=False,seed=3); dh=ImageDraw.Draw(h)
for x in range(0,32,2): dh.line([x,0,x+px.random.randint(-1,1),63],fill=(30,28,34,255))
for _ in range(20): x,y=px.random.randint(0,30),px.random.randint(0,60); dh.line([x,y,x,y+3],fill=(70,90,100,255))   # wet gleam
put("hair",h); put("bone",px.noise_tile(32,32,(200,196,180),var=12,seed=4))
put("rag",px.noise_tile(32,32,(210,212,205),var=20,bands=True,seed=5)); r=base.crop((64,64,96,96)); px.blotches(r,14,-50,seed=5); px.ragged_bottom(r,22,5,seed=5); put("rag",r)
put("stone",px.noise_tile(32,32,(80,86,80),var=14,seed=6)); st=base.crop((32,96,64,128)); px.moss(st,10,seed=6); put("stone",st)
f=px.noise_tile(32,32,(168,178,170),var=16,seed=7); df=ImageDraw.Draw(f)
for x in range(0,32,2): df.line([x,0,x+px.random.randint(-2,2),px.random.randint(14,30)],fill=(14,12,16,255),width=2)   # hair over face
df.rectangle([12,22,20,27],fill=(30,20,24,255)); 
for x in range(13,20,2): df.rectangle([x,22,x,24],fill=(220,210,190,255))                                                  # teeth
put("face",f); put("back",h.crop((0,0,32,32)))
put("eye",Image.new("RGBA",(32,32),(0,0,0,0))); put("water",Image.new("RGBA",(32,32),(0,0,0,0))); put("slime",Image.new("RGBA",(32,32),(0,0,0,0)))
def paint(fr,fi,t):
    d=ImageDraw.Draw(fr); k=(math.sin(t)+1)/2; k2=(math.sin(3*t)+1)/2
    ex,ey=tex.regions["eye"][:2]; d.ellipse([ex+8,ey+8,ex+23,ey+23],fill=(235,240,235,255)); d.ellipse([ex+13+int(2*math.sin(t*2)),ey+13,ex+18+int(2*math.sin(t*2)),ey+18],fill=(10,8,10,255))
    if k2>.85: d.rectangle([ex+8,ey+8,ex+23,ey+23],fill=(168,178,170,255))   # blink
    fx,fy=tex.regions["face"][:2]; 
    for cx in (9,21): d.ellipse([fx+cx-2,fy+15,fx+cx+2,fy+19],fill=(230,235,230,255)); d.point((fx+cx+int(math.sin(t)*1.5),fy+17),fill=(5,5,5,255))
    for cx in (9,21): d.line([fx+cx-3,fy+13,fx+cx+3,fy+13],fill=(14,12,16,255))
    wx,wy=tex.regions["water"][:2]
    for y in range(32):
        for x in range(32):
            v=(math.sin(x*.5+t)+math.sin(y*.4-t*1.4))/2; fr.putpixel((wx+x,wy+y),(40+int(30*v),70+int(30*v),90+int(30*v),150+int(60*v)))
    sx,sy=tex.regions["slime"][:2]
    for i in range(10):
        x=(i*7+3)%32; y=int((i*5+fi*1.6)%32); d.line([sx+x,sy+y,sx+x,sy+y+4],fill=(90,140,120,190)); d.point((sx+x,sy+y+5),fill=(150,200,180,220))
    hx,hy=tex.regions["hair"][:2]
    for i in range(12): x=(i*9+1)%32; y=int((i*11+fi*2)%64); fr.putpixel((hx+x,hy+y),(120,160,170,255))   # water drips in hair
strip=px.make_strip(base,FR,paint); tex.set_image(strip); strip.save("trio/well_monster.png"); json.dump(tex.mcmeta(),open("trio/well_monster.png.mcmeta","w"))

m=Model("well_monster",tex,fmt="free",seed=5)
m.bone("root",[0,0,0]); m.bone("body",[0,16,0],"root",rot=[-45,0,0]); m.bone("chest",[0,24,-4],"body",rot=[-10,0,0]); m.bone("neck",[0,30,-9],"chest",rot=[-35,0,0]); m.bone("head",[0,32,-12],"neck",rot=[-20,0,10]); m.bone("jaw",[0,30,-14],"head",rot=[-15,0,0])
m.bone("hair_front",[0,36,-15],"head"); m.bone("hair_back",[0,36,-9],"head")
m.bone("arm_left",[5,29,-7],"chest",rot=[50,0,-30]); m.bone("forearm_left",[9,18,-12],"arm_left",rot=[-90,0,0]); m.bone("hand_left",[10,17,-24],"forearm_left",rot=[0,0,0])
m.bone("arm_right",[-5,29,-7],"chest",rot=[80,0,25]); m.bone("forearm_right",[-9,18,-12],"arm_right",rot=[-40,0,0]); m.bone("hand_right",[-10,17,-24],"forearm_right")
m.bone("leg_left",[2.5,16,0],"root",rot=[-70,0,-10]); m.bone("shin_left",[3,10,-6],"leg_left",rot=[90,0,0]); m.bone("leg_right",[-2.5,16,0],"root",rot=[-30,0,15]); m.bone("shin_right",[-4,8,-2],"leg_right",rot=[60,0,0])
m.bone("rag",[0,20,2],"body")
for i in range(4): m.bone(f"drip_{i}",[0,20,-8],"chest")
# torso: emaciated, ribs & spine
m.cube("pelvis",[-4,14,-3],[4,20,3],"dskin","body"); m.cube("belly",[-3.5,18,-3],[3.5,25,2],"skin","body")
m.cube("ribcage",[-5,24,-5],[5,32,2],"skin","chest",faces={"south":"back"})
for i in range(4): m.cube(f"rib_l_{i}",[-5.4,25+i*1.6,-4.5],[-1,25.6+i*1.6,-3.5],"skin","chest",rot=[0,0,-6]); m.cube(f"rib_r_{i}",[1,25+i*1.6,-4.5],[5.4,25.6+i*1.6,-3.5],"skin","chest",rot=[0,0,6])
for i in range(7): m.cube(f"spine_{i}",[-.7,15+i*2.4,2 if i<3 else 1.6],[.7,16.4+i*2.4,3.3 if i<3 else 3],"bone","body" if i<3 else "chest")
m.cube("shoulders",[-6,29,-9],[6,32,-3],"skin","chest")
m.cube("neck",[-1.6,28,-13],[1.6,34,-8],"dskin","neck"); m.cube("neck_bone",[-.5,28,-11],[.5,35,-10],"bone","neck")
# head: tilted, long wet hair over face, mouth visible below
m.cube("skull",[-4,29,-17],[4,38,-9],"skin","head",faces={"north":"face"})
m.cube("jaw",[-3,26,-17],[3,29.5,-11],"skin","jaw"); m.cube("teeth_low",[-2.5,29,-17.3],[2.5,30,-15],"bone","jaw")
m.cube("tongue",[-.8,28.5,-20],[.8,29.3,-14],"dskin","jaw",rot=[15,0,0],origin=[0,29,-14])
m.cube("eye_l",[-3.2,33,-17.6],[-.8,35.4,-16.8],"eye","head",full=True); m.cube("eye_r",[.8,33,-17.6],[3.2,35.4,-16.8],"eye","head",full=True)
m.cube("hair_top",[-4.5,37.5,-17.5],[4.5,39,-8.5],"hair","head")
for i,x in enumerate((-4.4,-2.2,0,2.2)):
    m.cube(f"hair_f_{i}",[x,26-i%2*3,-18.2],[x+2.2,38,-17.2],"hair","hair_front",rot=[-4+i*2,0,0],origin=[x,38,-17.5])
m.cube("hair_side_l",[-5.2,24,-17],[-4.2,38,-9],"hair","head"); m.cube("hair_side_r",[4.2,26,-17],[5.2,38,-9],"hair","head")
m.cube("hair_back",[-4.6,14,-9.4],[4.6,38,-8.2],"hair","hair_back",rot=[5,0,0])
# arms: long, double-jointed
for sgn,a,fa,ha in ((1,"arm_left","forearm_left","hand_left"),(-1,"arm_right","forearm_right","hand_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(4,7.5); m.cube(f"upper_{a}",[xa,16,-9],[xb,30,-5.5],"skin",a)
    xa,xb=X(5,8); m.cube(f"elbow_{a}",[xa,16,-13.5],[xb,20,-10],"dskin",fa)
    xa,xb=X(7,10); m.cube(f"fore_{a}",[xa,16.5,-25],[xb,19.5,-11],"skin",fa)
    xa,xb=X(7.5,9.5); m.cube(f"fore_bone_{a}",[xa,15.5,-22],[xb,16.7,-14],"bone",fa)
    xa,xb=X(6.5,10.5); m.cube(f"hand_{a}",[xa,16,-28],[xb,18,-24],"dskin",ha)
    for i in range(4):
        xa,xb=X(6.6+i*1.05,7.4+i*1.05); m.cube(f"finger_{a}_{i}",[xa,16.2,-34],[xb,17.2,-28],"skin",ha,rot=[0,(i-1.5)*6*sgn,0],origin=[(xa+xb)/2,16.7,-28])
        m.cube(f"nail_{a}_{i}",[xa,16.4,-36.5],[xb,17,-34],"bone",ha,rot=[0,(i-1.5)*6*sgn,0],origin=[(xa+xb)/2,16.7,-28])
# legs: crouched, knees up
for sgn,lg,sh in ((1,"leg_left","shin_left"),(-1,"leg_right","shin_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(1,5); m.cube(f"thigh_{lg}",[xa,4,-3],[xb,16.5,1],"skin",lg)
    xa,xb=X(.5,5.5); m.cube(f"knee_{lg}",[xa,3,-4],[xb,7,1.5],"dskin",sh)
    xa,xb=X(1,5); m.cube(f"shin_{lg}",[xa,3.5,-14],[xb,6.5,-3],"skin",sh)
    xa,xb=X(.5,5.5); m.cube(f"foot_{lg}",[xa,3,-17],[xb,5,-13],"dskin",sh)
    for i in range(3): xa,xb=X(1+i*1.5,2+i*1.5); m.cube(f"toe_{lg}_{i}",[xa,3.2,-19.5],[xb,4.2,-17],"bone",sh)
m.cube("rag_dress",[-5,8,-3.5],[5,20,3.5],"rag","rag",full=True)
m.cube("rag_wet",[-5.2,8,-3.7],[5.2,14,3.7],"water","rag",full=True)
for i in range(4):
    a=math.radians(i*90+45); x,z=math.cos(a)*5,-4+math.sin(a)*5
    m.cube(f"drip_{i}",[x-.4,14-i*2,z-.4],[x+.4,20-i,z+.4],"slime",f"drip_{i}",full=True)
Z=[0,0,0]; L="linear"
drips=[f"drip_{i}" for i in range(4)]
def amb(length): return merge(wave("hair_front",length,6,1,.2),wave("hair_back",length,4,1,.6),{b:{"position":[(0,Z),(length/2,[0,-2,0]),(length,Z)]} for b in drips})
m.animation("idle",4,True,merge(amb(4),{"body":{"rotation":[(0,Z),(2,[3,0,0]),(4,Z)]},"head":{"rotation":[(0,Z),(.6,Z),(.7,[0,0,-25],L),(1.6,[0,0,-22]),(1.7,[5,30,15],L),(2.6,[2,25,12]),(2.7,[-5,-10,10],L),(3.4,[-2,-5,8]),(4,Z)]},
 "jaw":{"rotation":[(0,Z),(1.7,[-25,0,0]),(2.0,Z),(2.05,[-30,0,0],L),(2.2,Z),(4,Z)]},"arm_left":{"rotation":[(0,Z),(1,[5,0,-5]),(1.05,[-8,0,3],L),(2.5,[3,0,0]),(4,Z)]},"arm_right":{"rotation":[(0,Z),(1.6,[6,0,4]),(1.65,[-6,0,-3],L),(3,[2,0,0]),(4,Z)]},
 "hand_left":{"rotation":[(0,Z),(1,[0,0,0]),(1.1,[0,0,20],L),(1.3,[0,0,-15],L),(1.5,Z),(4,Z)]}}))
# CRAWL 1.2s loop: spider-like, arms alternate, body sways
m.animation("crawl",1.2,True,merge(amb(1.2),{"root":{"position":[(0,Z),(.3,[0,1,0]),(.6,Z),(.9,[0,1,0]),(1.2,Z)],"rotation":[(0,[0,0,5]),(.6,[0,0,-5]),(1.2,[0,0,5])]},
 "body":{"rotation":[(0,[0,6,0]),(.6,[0,-6,0]),(1.2,[0,6,0])]},"head":{"rotation":[(0,[0,-10,0]),(.3,[0,0,-10]),(.6,[0,10,0]),(.9,[0,0,10]),(1.2,[0,-10,0])]},
 "arm_left":{"rotation":[(0,[-35,0,0]),(.6,[35,0,10]),(1.2,[-35,0,0])]},"forearm_left":{"rotation":[(0,[10,0,0]),(.3,[-20,0,0]),(.6,[10,0,0]),(1.2,[10,0,0])]},
 "arm_right":{"rotation":[(0,[35,0,-10]),(.6,[-35,0,0]),(1.2,[35,0,-10])]},"forearm_right":{"rotation":[(0,[10,0,0]),(.6,[10,0,0]),(.9,[-20,0,0]),(1.2,[10,0,0])]},
 "leg_left":{"rotation":[(0,[30,0,0]),(.6,[-25,0,0]),(1.2,[30,0,0])]},"leg_right":{"rotation":[(0,[-25,0,0]),(.6,[30,0,0]),(1.2,[-25,0,0])]},"jaw":{"rotation":[(0,[-10,0,0]),(.6,[-25,0,0]),(1.2,[-10,0,0])]}}))
# LUNGE 1.1s: rears back on legs, springs forward with claws, bites
m.animation("lunge",1.1,False,merge({"root":{"position":[(0,Z),(.35,[0,3,3]),(.55,[0,-1,-8]),(.85,[0,0,-6]),(1.1,Z)]},"body":{"rotation":[(0,Z),(.35,[35,0,0]),(.55,[-15,0,0]),(1.1,Z)]},"chest":{"rotation":[(0,Z),(.35,[15,0,0]),(.55,[-10,0,0]),(1.1,Z)]},
 "neck":{"rotation":[(0,Z),(.35,[20,0,0]),(.55,[-15,0,0]),(1.1,Z)]},"head":{"rotation":[(0,Z),(.35,[10,0,-10]),(.55,[-10,0,0]),(.65,[-8,0,0]),(1.1,Z)]},"jaw":{"rotation":[(0,Z),(.35,[-50,0,0]),(.55,[10,0,0],L),(.6,[-25,0,0],L),(.66,[10,0,0],L),(.9,[-20,0,0]),(1.1,Z)]},
 "arm_left":{"rotation":[(0,Z),(.35,[-60,0,-30]),(.55,[40,0,10]),(1.1,Z)]},"arm_right":{"rotation":[(0,Z),(.35,[-70,0,30]),(.55,[30,0,-10]),(1.1,Z)]},"forearm_left":{"rotation":[(0,Z),(.35,[-30,0,0]),(.55,[30,0,0]),(1.1,Z)]},"forearm_right":{"rotation":[(0,Z),(.35,[-20,0,0]),(.55,[35,0,0]),(1.1,Z)]},
 "hand_left":{"rotation":[(0,Z),(.35,[0,0,30]),(.55,[0,0,-20]),(1.1,Z)]},"hand_right":{"rotation":[(0,Z),(.35,[0,0,-30]),(.55,[0,0,20]),(1.1,Z)]},"leg_left":{"rotation":[(0,Z),(.35,[40,0,0]),(.55,[-30,0,0]),(1.1,Z)]},"leg_right":{"rotation":[(0,Z),(.35,[40,0,0]),(.55,[-30,0,0]),(1.1,Z)]},
 "hair_front":{"rotation":[(0,Z),(.35,[-25,0,0]),(.6,[30,0,0]),(1.1,Z)]}}))
# CLIMB OUT OF WELL 5s: starts below, hand slaps rim, other hand, head peeks, hauls up, unfolds onto all fours
m.animation("climb_out",5,False,merge({"root":{"position":[(0,[0,-40,0],L),(.6,[0,-40,0],L),(2.2,[0,-38,0]),(2.8,[0,-30,0]),(3.2,[0,-31,0]),(3.7,[0,-18,0]),(4.1,[0,-6,0]),(4.5,[0,1,0]),(5,Z)],"rotation":[(0,[-40,0,0],L),(3.2,[-40,0,0]),(4.1,[-10,0,0]),(4.6,[4,0,0]),(5,Z)]},
 "arm_left":{"rotation":[(0,[70,0,-10],L),(.6,[70,0,-10],L),(.75,[95,0,-20],L),(.8,[80,0,-5],L),(.85,[90,0,-8],L),(2.2,[88,0,-8]),(3.2,[60,0,-10]),(4.1,[10,0,-5]),(5,Z)]},"forearm_left":{"rotation":[(0,[-60,0,0],L),(.6,[-60,0,0],L),(.8,[-70,0,0],L),(2.2,[-70,0,0]),(3.2,[-40,0,0]),(4.1,[-5,0,0]),(5,Z)]},
 "hand_left":{"rotation":[(0,Z,L),(.8,[0,0,0],L),(.95,[0,0,40],L),(1.1,[0,0,-20],L),(1.3,[0,0,10],L),(1.5,Z),(5,Z)]},
 "arm_right":{"rotation":[(0,[70,0,10],L),(1.6,[70,0,10],L),(1.75,[95,0,20],L),(1.8,[80,0,5],L),(1.85,[90,0,8],L),(2.2,[88,0,8]),(3.2,[60,0,10]),(4.1,[10,0,5]),(5,Z)]},"forearm_right":{"rotation":[(0,[-60,0,0],L),(1.6,[-60,0,0],L),(1.8,[-70,0,0],L),(2.2,[-70,0,0]),(3.2,[-40,0,0]),(4.1,[-5,0,0]),(5,Z)]},
 "hand_right":{"rotation":[(0,Z,L),(1.8,Z,L),(1.95,[0,0,-40],L),(2.1,[0,0,20],L),(2.3,[0,0,-10],L),(2.5,Z),(5,Z)]},
 "neck":{"rotation":[(0,[-30,0,0],L),(2.2,[-30,0,0]),(2.6,[20,0,0]),(3.0,[25,20,0]),(3.2,[25,-25,0]),(3.5,[15,0,0]),(4.3,[-5,0,0]),(5,Z)]},"head":{"rotation":[(0,[-20,0,0],L),(2.2,[-20,0,0]),(2.6,[-10,0,-30]),(2.7,[-10,0,-32],L),(3.0,[-10,0,28],L),(3.4,[0,0,10]),(4,[5,0,-5]),(5,Z)]},
 "jaw":{"rotation":[(0,[15,0,0],L),(2.6,[15,0,0]),(2.9,[-40,0,0]),(3.3,[-10,0,0]),(3.6,[-45,0,0]),(4.2,[-15,0,0]),(5,Z)]},"body":{"rotation":[(0,[-20,0,0],L),(2.8,[-20,0,0]),(3.7,[10,0,0]),(4.3,[-5,0,0]),(5,Z)]},
 "leg_left":{"rotation":[(0,[40,0,0],L),(3.7,[40,0,0]),(4.3,[-20,0,0]),(5,Z)]},"leg_right":{"rotation":[(0,[40,0,0],L),(3.9,[40,0,0]),(4.5,[-15,0,0]),(5,Z)]},"hair_front":{"rotation":[(0,[10,0,0],L),(2.6,[10,0,0]),(3.0,[-20,0,0]),(3.5,[15,0,0]),(4.2,[-5,0,0]),(5,Z)]}},
 {b:{"position":[(0,Z),(3,Z),(4.2,[0,-6,0]),(5,Z)]} for b in drips}))
# SCREECH 1.6s: head snaps up, hair flies back, mouth wide, tremor
m.animation("screech",1.6,False,merge({"body":{"rotation":[(0,Z),(.4,[25,0,0]),(1.1,[28,0,0]),(1.6,Z)]},"neck":{"rotation":[(0,Z),(.4,[35,0,0]),(1.1,[38,0,0]),(1.6,Z)]},
 "head":{"rotation":[(0,Z),(.4,[20,0,-10]),(.5,[22,5,-10],L),(.6,[20,-5,-10],L),(.7,[23,4,-10],L),(.8,[20,-4,-10],L),(.9,[22,3,-10],L),(1.1,[20,0,-10]),(1.6,Z)]},"jaw":{"rotation":[(0,Z),(.4,[-60,0,0]),(1.1,[-65,0,0]),(1.6,Z)]},
 "hair_front":{"rotation":[(0,Z),(.4,[-50,0,0]),(1.1,[-55,0,0]),(1.6,Z)]},"arm_left":{"rotation":[(0,Z),(.4,[-30,0,-50]),(1.1,[-35,0,-55]),(1.6,Z)]},"arm_right":{"rotation":[(0,Z),(.4,[-40,0,50]),(1.1,[-45,0,55]),(1.6,Z)]},
 "hand_left":{"rotation":[(0,Z),(.4,[0,0,40]),(1.6,Z)]},"hand_right":{"rotation":[(0,Z),(.4,[0,0,-40]),(1.6,Z)]},"root":{"position":[(0,Z),(.4,[0,2,0]),(1.1,[0,2,0]),(1.6,Z)]}}))
# DEATH 2.5s: collapses flat, limbs splay, twitch
m.animation("death",2.5,False,merge({"root":{"position":[(0,Z),(.5,[0,-2,0]),(1.0,[0,-9,0]),(1.4,[0,-10,0]),(2.5,[0,-10,0],L)],"rotation":[(0,Z),(1.0,[40,0,8]),(1.4,[42,0,8]),(2.5,[42,0,8],L)]},
 "body":{"rotation":[(0,Z),(.5,[10,0,0]),(1.0,[20,0,0]),(2.5,[20,0,0],L)]},"neck":{"rotation":[(0,Z),(1.0,[30,0,0]),(2.5,[30,0,0],L)]},"head":{"rotation":[(0,Z),(.5,[0,30,20]),(1.0,[10,-20,40]),(1.6,[10,-20,40]),(1.7,[14,-20,40],L),(1.8,[10,-20,40],L),(2.5,[10,-20,40],L)]},
 "jaw":{"rotation":[(0,Z),(.5,[-40,0,0]),(2.5,[-35,0,0],L)]},"arm_left":{"rotation":[(0,Z),(1.0,[-30,0,-40]),(2.5,[-30,0,-40],L)]},"arm_right":{"rotation":[(0,Z),(1.0,[-20,0,40]),(1.9,[-20,0,40]),(2.0,[-25,0,42],L),(2.1,[-20,0,40],L),(2.5,[-20,0,40],L)]},
 "forearm_left":{"rotation":[(0,Z),(1.0,[40,0,0]),(2.5,[40,0,0],L)]},"forearm_right":{"rotation":[(0,Z),(1.0,[50,0,0]),(2.5,[50,0,0],L)]},"leg_left":{"rotation":[(0,Z),(1.0,[30,0,-30]),(2.5,[30,0,-30],L)]},"leg_right":{"rotation":[(0,Z),(1.0,[30,0,30]),(2.5,[30,0,30],L)]}}))
m.save("trio/well_monster.bbmodel"); m.save_bedrock_animation("trio/well_monster.animation.json"); print("well",len(m.elements),[a["name"] for a in m.animations])
