import sys, math, json, random
sys.path.insert(0, "/home/user/skills/blockbench-modeler/lib")
from PIL import Image, ImageDraw
from bbmodel import Model, Texture, merge, wave, chain_wave
import pixelart as px
random.seed(7)
W,FR=128,16
tex=Texture(W,W,FR,name="pale_one",frame_time=6,interpolate=True)
R={"skin":(0,0,32,64),"skin2":(32,0,64,64),"face":(64,0,96,32),"leaf":(96,0,128,32),"twig":(64,32,96,64),"joint":(96,32,128,64),"palm":(0,64,32,96),"eye":(32,64,64,96),"moss":(64,64,96,96),"acorn":(96,64,128,96),"leafcap":(0,96,32,128),"back":(32,96,64,128),"claw":(64,96,96,128),"lichen":(96,96,128,128)}
for k,r in R.items(): tex.region(k,*r)
def pale(w,h,seed,base=(226,222,208)):
    im=px.noise_tile(w,h,base,var=10,bevel=False,seed=seed); d=ImageDraw.Draw(im)
    for _ in range(w*h//40): x,y=random.randint(0,w-1),random.randint(0,h-3); d.line([x,y,x+random.randint(-1,1),y+random.randint(2,6)],fill=(190,185,170,255))   # sinews
    for _ in range(w*h//60): x,y=random.randint(0,w-1),random.randint(0,h-1); im.putpixel((x,y),(120,150,170,255))   # veins
    for _ in range(w*h//120): x,y=random.randint(0,w-1),random.randint(0,h-1); im.putpixel((x,y),(240,238,230,255))
    return im
def bark(w,h,seed):
    im=px.noise_tile(w,h,(96,72,46),var=16,bevel=False,seed=seed); d=ImageDraw.Draw(im)
    x=0
    while x<w:
        y=0
        while y<h:
            ln=random.randint(4,12); d.line([x,y,x+random.randint(-1,1),y+ln],fill=(58,42,26,255)); y+=ln+random.randint(1,4)
        x+=random.randint(2,4)
    for _ in range(w*h//30): x,y=random.randint(0,w-1),random.randint(0,h-1); im.putpixel((x,y),(130,102,66,255))
    px.moss(im,w*h//50,seed=seed)
    return im
def leaves(w,h,seed,alpha=255):
    im=Image.new("RGBA",(w,h),(0,0,0,0)); d=ImageDraw.Draw(im); random.seed(seed)
    for _ in range(w*h//14):
        x,y=random.randint(-2,w),random.randint(-2,h); c=random.choice([(70,110,40),(96,140,52),(120,160,60),(58,92,36),(150,120,40)])
        d.rectangle([x,y,x+random.randint(2,4),y+random.randint(2,3)],fill=c+(alpha,)); d.point((x+1,y+1),fill=(c[0]+30,c[1]+30,c[2]+10,alpha))
    return im
def leaves_full(w,h,seed):
    im=px.noise_tile(w,h,(76,116,44),var=14,bevel=False,seed=seed); im.alpha_composite(leaves(w,h,seed+1)); return im
def face(pale_mode):
    im=(pale(32,32,21) if pale_mode else bark(32,32,22)); d=ImageDraw.Draw(im)
    for cx in (9,22):  # deep hollow sockets
        d.ellipse([cx-4,9,cx+4,18],fill=(30,28,26,255)); d.ellipse([cx-3,10,cx+3,17],fill=(12,10,10,255))
    d.line([15,20,16,25],fill=(170,165,150,255) if pale_mode else (60,44,28,255))  # nose slit
    d.rectangle([9,27,22,28],fill=(60,40,40,255)); 
    for x in range(10,22,3): d.line([x,27,x,29],fill=(200,200,190,255))  # thin teeth
    if not pale_mode: im.alpha_composite(leaves(32,32,23,alpha=200))
    return im
def paint_frame(k,fi):
    """k in [0,1]: 0 = pale, 1 = fully camouflaged"""
    base=Image.new("RGBA",(W,W),(0,0,0,0)); put=lambda key,im: base.paste(im,R[key][:2])
    random.seed(1); P=pale(32,64,1); random.seed(2); B=bark(32,64,2); B2=B.copy(); B2.alpha_composite(leaves(32,64,3,alpha=190))
    put("skin",Image.blend(P,B2,k))
    random.seed(4); P2=pale(32,64,4,(214,208,192)); random.seed(5); B3=bark(32,64,5); put("skin2",Image.blend(P2,B3,k))
    random.seed(6); put("face",Image.blend(face(True),face(False),k))
    random.seed(8); L=leaves_full(32,32,8); Lp=L.copy(); Lp.putalpha(Lp.getchannel("A").point(lambda a:int(a*(0.15+0.85*k)))); put("leaf",Lp)
    random.seed(9); T=bark(32,32,9); Tp=pale(32,32,10,(200,195,180)); put("twig",Image.blend(Tp,T,min(1,k*1.5)))
    random.seed(11); J=pale(32,32,11,(190,180,160)); Jd=ImageDraw.Draw(J)
    for y in range(0,32,4): Jd.line([0,y,31,y],fill=(160,150,130,255))
    Jb=bark(32,32,12); put("joint",Image.blend(J,Jb,k))
    random.seed(13); pm=pale(32,32,13,(200,190,180)); pmd=ImageDraw.Draw(pm); pmd.ellipse([8,8,24,24],outline=(150,120,120,255)); put("palm",Image.blend(pm,bark(32,32,14),k))
    random.seed(15); M=px.noise_tile(32,32,(70,110,50),var=14,bevel=False,seed=15); px.moss(M,150,seed=15); Mp=M.copy(); Mp.putalpha(Mp.getchannel("A").point(lambda a:int(a*(0.1+0.9*k)))); put("moss",Mp)
    random.seed(16); A=px.noise_tile(32,32,(140,100,50),var=12,seed=16); Ad=ImageDraw.Draw(A); Ad.rectangle([0,0,31,12],fill=(90,64,36,255))
    for x in range(0,32,3): Ad.line([x,0,x,12],fill=(70,50,28,255))
    put("acorn",A)
    random.seed(17); C=leaves_full(32,32,17); Cd=ImageDraw.Draw(C)
    for _ in range(6): x,y=random.randint(0,28),random.randint(0,28); Cd.line([x,y,x+3,y+3],fill=(120,90,50,255))
    put("leafcap",C)
    random.seed(18); bk=pale(32,32,18,(210,205,190)); bkd=ImageDraw.Draw(bk)
    for y in range(2,32,4): bkd.rectangle([13,y,18,y+1],fill=(170,160,145,255))  # spine
    bb=bark(32,32,19); bb.alpha_composite(leaves(32,32,20,alpha=210)); put("back",Image.blend(bk,bb,k))
    random.seed(24); cl=px.noise_tile(32,32,(60,50,44),var=10,seed=24); put("claw",cl)
    random.seed(25); li=px.noise_tile(32,32,(150,170,140),var=12,bevel=False,seed=25); lid=ImageDraw.Draw(li)
    for _ in range(40): x,y=random.randint(0,30),random.randint(0,30); lid.ellipse([x,y,x+2,y+2],fill=(190,205,170,255))
    lip=li.copy(); lip.putalpha(lip.getchannel("A").point(lambda a:int(a*(0.05+0.95*k)))); put("lichen",lip)
    # eyes: pale = glowing faint white-green pinpricks; camo = dark
    E=Image.new("RGBA",(32,32),(0,0,0,0)); Ed=ImageDraw.Draw(E); g=1-k; pulse=.5+.5*math.sin(fi/FR*2*math.pi*2)
    Ed.ellipse([4,4,27,27],fill=(int(20+10*g),int(24+16*g),int(20+10*g),255)); Ed.ellipse([10,10,21,21],fill=(int(120+120*g*pulse),int(180+70*g),int(120+90*g),255)); Ed.ellipse([13,13,18,18],fill=(int(220*g+20),int(255*g+30),int(200*g+20),255))
    put("eye",E)
    # subtle exposed pale rim for the face socket area is handled by face blend
    return base
frames=[]
for fi in range(FR):
    k=(1-math.cos(2*math.pi*fi/FR))/2; k=k**1.3 if k<.5 else k  # hold pale a bit longer
    frames.append(paint_frame(k,fi))
strip=Image.new("RGBA",(W,W*FR)); [strip.paste(f,(0,i*W)) for i,f in enumerate(frames)]
tex.set_image(strip); strip.save("forest/pale_one.png"); json.dump(tex.mcmeta(),open("forest/pale_one.png.mcmeta","w"))

m=Model("pale_one",tex,fmt="free",seed=21)
# --- skeleton: 3.5 blocks tall, gaunt, hunched
m.bone("root",[0,0,0]); m.bone("hips",[0,26,0],"root"); m.bone("spine",[0,30,0],"hips",rot=[-14,0,0]); m.bone("chest",[0,40,0],"spine",rot=[-10,0,0]); m.bone("neck",[0,50,1],"chest",rot=[20,0,0]); m.bone("head",[0,55,0],"neck",rot=[8,0,0])
m.bone("jaw",[0,50.5,-2],"head"); m.bone("crown",[0,63,0],"head")
for i in range(5): m.bone(f"twig_{i}",[0,63,0],"crown")
m.bone("arm_left",[6,48,0],"chest",rot=[-12,0,-6]); m.bone("fore_left",[7.5,30,0],"arm_left",rot=[-14,0,0]); m.bone("hand_left",[8,14,0],"fore_left",rot=[10,0,0])
m.bone("arm_right",[-6,48,0],"chest",rot=[-8,0,6]); m.bone("fore_right",[-7.5,30,0],"arm_right",rot=[-18,0,0]); m.bone("hand_right",[-8,14,0],"fore_right",rot=[12,0,0])
m.bone("leg_left",[3,26,0],"hips",rot=[-8,0,0]); m.bone("shin_left",[3,13,0],"leg_left",rot=[16,0,0]); m.bone("foot_left",[3,3,0],"shin_left",rot=[-8,0,0])
m.bone("leg_right",[-3,26,0],"hips",rot=[12,0,0]); m.bone("shin_right",[-3,13,0],"leg_right",rot=[8,0,0]); m.bone("foot_right",[-3,3,0],"shin_right",rot=[-20,0,0])
for i in range(6): m.bone(f"leaf_{i}",[0,40,0],"root")
# --- torso
m.cube("pelvis",[-4,24,-2.5],[4,30,2.5],"skin2","hips"); m.cube("hip_moss",[-4.3,24.5,1.8],[4.3,28,3],"moss","hips")
m.cube("belly",[-3,30,-2],[3,40,2],"skin","spine"); m.cube("rib_l",[-4,33,-2.6],[-1,39,2.6],"skin2","spine",rot=[0,0,-6]); m.cube("rib_r",[1,33,-2.6],[4,39,2.6],"skin2","spine",rot=[0,0,6])
m.cube("chest",[-5,40,-3],[5,50,3],"skin","chest",faces={"south":"back"}); m.cube("collar",[-6,48.5,-3.4],[6,51,3.4],"skin2","chest")
m.cube("shoulder_leaf_l",[4.5,49,-4],[9,53,4],"leaf","chest",rot=[0,0,-25],origin=[6,50,0],full=True); m.cube("shoulder_leaf_r",[-9,49,-4],[-4.5,53,4],"leaf","chest",rot=[0,0,25],origin=[-6,50,0],full=True)
m.cube("back_hump",[-4,43,2.5],[4,50,5.5],"back","chest"); m.cube("back_moss",[-3,44,5.2],[3,48,6.5],"moss","chest"); m.cube("back_lichen",[-5,41,2.7],[-1,45,4.5],"lichen","chest")
for i in range(5): m.cube(f"spine_spike_{i}",[-.7,31+i*4,2.2],[.7,32.5+i*4,4.5],"twig","spine" if i<2 else "chest",rot=[-30,0,0],origin=[0,31.5+i*4,2.2])
m.cube("neck",[-2,49.5,-1.5],[2,55.5,1.5],"skin2","neck")
# --- head: narrow, elongated skull
m.cube("skull",[-4,55,-4],[4,64,4],"skin","head",faces={"north":"face"}); m.cube("skull_top",[-3.5,63.5,-3.5],[3.5,66,3.5],"skin2","head"); m.cube("skull_back",[-3.5,56,3.5],[3.5,63,6],"back","head")
m.cube("eye_l",[-3.4,59.5,-4.5],[-.8,61.5,-3.8],"eye","head",full=True); m.cube("eye_r",[.8,59.5,-4.5],[3.4,61.5,-3.8],"eye","head",full=True)
m.cube("brow",[-4.2,61.5,-4.6],[4.2,62.8,-3.6],"twig","head"); m.cube("cheek_l",[-4.4,56,-3.5],[-3.6,59.5,-1],"skin2","head"); m.cube("cheek_r",[3.6,56,-3.5],[4.4,59.5,-1],"skin2","head")
m.cube("jaw",[-3.5,50.5,-4.2],[3.5,53.5,1],"skin2","jaw",rot=[6,0,0],origin=[0,53.5,1])
for i in range(3): m.cube(f"tooth_{i}",[-2.5+i*2,53.4,-4],[-1.9+i*2,54.6,-3.4],"claw","jaw")
m.cube("leaf_cap",[-4.5,64.5,-4.5],[4.5,66.5,4.5],"leafcap","crown",full=True); m.cube("leaf_cap2",[-3,66,-6],[3,67.5,-2],"leafcap","crown",rot=[15,0,0],full=True)
for i,(rx,rz,l) in enumerate(((-30,35,9),(-20,-35,8),(25,20,10),(20,-25,7),(-5,0,12))):
    m.cube(f"twig_{i}",[-.6,65,-.6],[.6,65+l,.6],"twig",f"twig_{i}",rot=[rx,0,rz],origin=[0,65,0]); m.cube(f"twig_{i}b",[-.5,65+l*.6,-.5],[.5,65+l*.6+l*.5,.5],"twig",f"twig_{i}",rot=[rx+15,0,rz-25],origin=[0,65+l*.6,0])
    m.cube(f"twig_{i}_leaf",[-1.8,65+l-1,-1.8],[1.8,65+l+1,1.8],"leaf",f"twig_{i}",rot=[rx,20,rz],origin=[0,65,0],full=True)
# --- arms: very long, reach the ground
for sgn,a,f,h in ((1,"arm_left","fore_left","hand_left"),(-1,"arm_right","fore_right","hand_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(5.5,9.5); m.cube(f"shoulder_{a}",[xa,45,-2],[xb,50,2],"joint",a); xa,xb=X(6,9); m.cube(f"upper_{a}",[xa,30,-1.5],[xb,46,1.5],"skin",a)
    xa,xb=X(5.8,9.2); m.cube(f"elbow_{a}",[xa,28.5,-1.8],[xb,31.5,1.8],"joint",f); xa,xb=X(6.3,8.7); m.cube(f"fore_{a}",[xa,14,-1.2],[xb,29,1.2],"skin2",f)
    xa,xb=X(6,9.2); m.cube(f"fore_moss_{a}",[xa,18,-1.4],[xb,24,1.4],"moss",f)
    xa,xb=X(5.8,9.6); m.cube(f"hand_{a}",[xa,9,-1.5],[xb,14.5,1.5],"palm",h)
    for i in range(4):
        xa,xb=X(5.9+i*.95,6.6+i*.95); m.cube(f"finger_{a}_{i}",[xa,2.5,-1],[xb,9.2,-.2],"skin2",h,rot=[-12+i*4,0,0],origin=[(xa+xb)/2,9.2,-.6]); m.cube(f"claw_{a}_{i}",[xa+.1,-.5,-1],[xb-.1,2.6,-.4],"claw",h,rot=[-20+i*4,0,0],origin=[(xa+xb)/2,2.6,-.7])
    xa,xb=X(9.4,10.4); m.cube(f"thumb_{a}",[xa,8,-1],[xb,12.5,0],"skin2",h,rot=[0,0,sgn*-30],origin=[sgn*9.5,12.5,-.5])
# --- legs: long, digitigrade-ish
for sgn,l,s,ft in ((1,"leg_left","shin_left","foot_left"),(-1,"leg_right","shin_right","foot_right")):
    X=lambda p,q:[min(sgn*p,sgn*q),max(sgn*p,sgn*q)]
    xa,xb=X(1.2,4.8); m.cube(f"thigh_{l}",[xa,13,-2],[xb,26,2],"skin2",l); xa,xb=X(1,5); m.cube(f"knee_{l}",[xa,11.5,-2.3],[xb,14.5,2.3],"joint",s)
    xa,xb=X(1.6,4.4); m.cube(f"shin_{l}",[xa,3,-1.5],[xb,12,1.5],"skin",s); xa,xb=X(1.4,4.6); m.cube(f"shin_lichen_{l}",[xa,5,-1.7],[xb,9,1.7],"lichen",s)
    xa,xb=X(1,5); m.cube(f"foot_{l}",[xa,0,-5],[xb,2.5,2],"skin2",ft,faces={"up":"moss"})
    for i in range(3): xa,xb=X(1.2+i*1.3,2.2+i*1.3); m.cube(f"toe_{l}_{i}",[xa,0,-7.5],[xb,1.5,-4.8],"claw",ft,rot=[8,0,0],origin=[(xa+xb)/2,1,-5])
    xa,xb=X(2.2,3.8); m.cube(f"heel_spur_{l}",[xa,1,2],[xb,2.5,4.5],"claw",ft,rot=[25,0,0],origin=[(xa+xb)/2,2,2])
# --- floating leaves (drift around)
for i in range(6):
    a=math.radians(i*60); x,z=math.cos(a)*9,math.sin(a)*9; y=20+i*7
    m.cube(f"leaf_{i}",[x-1.5,y-.2,z-1.5],[x+1.5,y+.2,z+1.5],"leaf",f"leaf_{i}",full=True,rot=[random.randint(-40,40),random.randint(0,90),random.randint(-40,40)],origin=[x,y,z])
Z=[0,0,0]; L="linear"; leaves_b=[f"leaf_{i}" for i in range(6)]; twigs=[f"twig_{i}" for i in range(5)]
def amb(length,drift=1):
    d={b:{"position":[(length*k/8,[math.cos(2*math.pi*k/8+i)*2*drift,math.sin(2*math.pi*k/8*2+i)*1.5*drift,math.sin(2*math.pi*k/8+i)*2*drift]) for k in range(9)],"rotation":[(0,Z,L),(length,[0,360,0],L)]} for i,b in enumerate(leaves_b)}
    return merge(d,chain_wave(twigs,length,3,1,.8,axis=2),wave("jaw",length,2,1,.5))
m.animation("idle",5,True,merge(amb(5),{"spine":{"rotation":[(0,Z),(2.5,[-2,0,0]),(5,Z)]},"chest":{"rotation":[(0,Z),(2.5,[-3,0,0]),(5,Z)],"position":[(0,Z),(2.5,[0,-.5,0]),(5,Z)]},
 "neck":{"rotation":[(0,Z),(1.2,[0,35,8]),(1.8,[0,40,10],L),(2.7,[5,-30,-6]),(3.6,[5,-35,-8],L),(4.4,Z),(5,Z)]},"head":{"rotation":[(0,Z),(1.4,[0,0,15]),(3.0,[0,0,-15]),(5,Z)]},
 "arm_left":{"rotation":[(0,Z),(2.5,[4,0,-2]),(5,Z)]},"arm_right":{"rotation":[(0,Z),(2.5,[3,0,2]),(5,Z)]},"hand_left":{"rotation":[(0,Z),(1,[15,0,0]),(2,[-10,0,0]),(3,[12,0,0]),(5,Z)]},"hand_right":{"rotation":[(0,Z),(1.5,[12,0,0]),(2.5,[-8,0,0]),(3.5,[10,0,0]),(5,Z)]}}))
# WALK: slow stalking stride 1.8s, arms swing loosely, knees high
m.animation("walk",1.8,True,merge(amb(1.8),{"root":{"position":[(0,Z),(.45,[0,1.5,0]),(.9,Z),(1.35,[0,1.5,0]),(1.8,Z)]},"hips":{"rotation":[(0,[0,8,3]),(.9,[0,-8,-3]),(1.8,[0,8,3])]},"spine":{"rotation":[(0,[-6,-6,0]),(.9,[-6,6,0]),(1.8,[-6,-6,0])]},
 "head":{"rotation":[(0,[0,6,-4]),(.9,[0,-6,4]),(1.8,[0,6,-4])]},"leg_left":{"rotation":[(0,[-45,0,0]),(.45,[-20,0,0]),(.9,[35,0,0]),(1.35,[10,0,0]),(1.8,[-45,0,0])]},"shin_left":{"rotation":[(0,[15,0,0]),(.45,[5,0,0]),(.9,[10,0,0]),(1.35,[70,0,0]),(1.8,[15,0,0])]},"foot_left":{"rotation":[(0,[-10,0,0]),(.9,[25,0,0]),(1.35,[40,0,0]),(1.8,[-10,0,0])]},
 "leg_right":{"rotation":[(0,[35,0,0]),(.45,[10,0,0]),(.9,[-45,0,0]),(1.35,[-20,0,0]),(1.8,[35,0,0])]},"shin_right":{"rotation":[(0,[10,0,0]),(.45,[70,0,0]),(.9,[15,0,0]),(1.35,[5,0,0]),(1.8,[10,0,0])]},"foot_right":{"rotation":[(0,[25,0,0]),(.45,[40,0,0]),(.9,[-10,0,0]),(1.8,[25,0,0])]},
 "arm_left":{"rotation":[(0,[25,0,0]),(.9,[-25,0,0]),(1.8,[25,0,0])]},"fore_left":{"rotation":[(0,[-5,0,0]),(.45,[-25,0,0]),(.9,[-5,0,0]),(1.35,[-20,0,0]),(1.8,[-5,0,0])]},"arm_right":{"rotation":[(0,[-25,0,0]),(.9,[25,0,0]),(1.8,[-25,0,0])]},"fore_right":{"rotation":[(0,[-5,0,0]),(.45,[-20,0,0]),(.9,[-5,0,0]),(1.35,[-25,0,0]),(1.8,[-5,0,0])]},
 "hand_left":{"rotation":[(0,[20,0,0]),(.9,[-15,0,0]),(1.8,[20,0,0])]},"hand_right":{"rotation":[(0,[-15,0,0]),(.9,[20,0,0]),(1.8,[-15,0,0])]}}))
# TREE_FORM: freezes as an oak — straightens, arms rise as branches, twigs spread; loop with tiny sway (camo texture cycle does the colour)
m.animation("tree_form",6,True,merge({"spine":{"rotation":[(0,[14,0,0]),(3,[15,0,1]),(6,[14,0,0])]},"chest":{"rotation":[(0,[10,0,0]),(3,[11,0,-1]),(6,[10,0,0])]},"neck":{"rotation":[(0,[-20,0,0]),(6,[-20,0,0])]},"head":{"rotation":[(0,[-20,0,0]),(3,[-19,0,2]),(6,[-20,0,0])]},
 "arm_left":{"rotation":[(0,[-150,0,-45]),(3,[-150,0,-47]),(6,[-150,0,-45])]},"fore_left":{"rotation":[(0,[-30,0,-20]),(3,[-33,0,-20]),(6,[-30,0,-20])]},"hand_left":{"rotation":[(0,[-40,0,0]),(3,[-45,0,0]),(6,[-40,0,0])]},
 "arm_right":{"rotation":[(0,[-140,0,40]),(3,[-140,0,42]),(6,[-140,0,40])]},"fore_right":{"rotation":[(0,[-40,0,25]),(3,[-43,0,25]),(6,[-40,0,25])]},"hand_right":{"rotation":[(0,[-30,0,0]),(3,[-35,0,0]),(6,[-30,0,0])]},
 "leg_left":{"rotation":[(0,[8,0,-4]),(6,[8,0,-4])]},"shin_left":{"rotation":[(0,[-16,0,0]),(6,[-16,0,0])]},"foot_left":{"rotation":[(0,[8,0,0]),(6,[8,0,0])]},"leg_right":{"rotation":[(0,[-12,0,4]),(6,[-12,0,4])]},"shin_right":{"rotation":[(0,[-8,0,0]),(6,[-8,0,0])]},"foot_right":{"rotation":[(0,[20,0,0]),(6,[20,0,0])]},
 "root":{"rotation":[(0,[0,0,0]),(3,[1,0,1]),(6,Z)]},"jaw":{"rotation":[(0,[-6,0,0]),(6,[-6,0,0])]}},
 {b:{"rotation":[(0,[i*10-20,0,i*15-30]),(3,[i*10-18,0,i*15-26]),(6,[i*10-20,0,i*15-30])]} for i,b in enumerate(twigs)},
 {b:{"position":[(0,[0,-4,0]),(6,[0,-4,0])],"scale":[(0,[1.6,1.6,1.6]),(6,[1.6,1.6,1.6])]} for b in leaves_b}))
# UNFOLD: from tree_form back to creature 2.2s (play after tree_form)
m.animation("unfold",2.2,False,merge({"spine":{"rotation":[(0,[14,0,0]),(1.2,[-6,0,0]),(1.7,[2,0,0]),(2.2,Z)]},"chest":{"rotation":[(0,[10,0,0]),(1.2,[-5,0,0]),(2.2,Z)]},"neck":{"rotation":[(0,[-20,0,0]),(.6,[-20,0,0]),(1.0,[20,40,0]),(1.5,[10,-35,0]),(2.2,Z)]},"head":{"rotation":[(0,[-20,0,0]),(1.0,[0,0,20]),(1.5,[0,0,-15]),(2.2,Z)]},
 "arm_left":{"rotation":[(0,[-150,0,-45]),(.5,[-150,0,-45]),(1.3,[-20,0,-10]),(1.7,[8,0,-2]),(2.2,Z)]},"fore_left":{"rotation":[(0,[-30,0,-20]),(1.3,[-40,0,0]),(2.2,Z)]},"hand_left":{"rotation":[(0,[-40,0,0]),(1.3,[30,0,0]),(2.2,Z)]},
 "arm_right":{"rotation":[(0,[-140,0,40]),(.7,[-140,0,40]),(1.5,[-20,0,10]),(1.9,[8,0,2]),(2.2,Z)]},"fore_right":{"rotation":[(0,[-40,0,25]),(1.5,[-40,0,0]),(2.2,Z)]},"hand_right":{"rotation":[(0,[-30,0,0]),(1.5,[30,0,0]),(2.2,Z)]},
 "leg_left":{"rotation":[(0,[8,0,-4]),(1.2,[8,0,-4]),(2.2,Z)]},"shin_left":{"rotation":[(0,[-16,0,0]),(1.2,[-16,0,0]),(2.2,Z)]},"leg_right":{"rotation":[(0,[-12,0,4]),(1.4,[-12,0,4]),(2.2,Z)]},"shin_right":{"rotation":[(0,[-8,0,0]),(1.4,[-8,0,0]),(2.2,Z)]},"foot_right":{"rotation":[(0,[20,0,0]),(1.4,[20,0,0]),(2.2,Z)]},
 "jaw":{"rotation":[(0,[-6,0,0]),(.9,[-6,0,0]),(1.1,[25,0,0]),(1.6,[20,0,0]),(2.2,Z)]}},
 {b:{"rotation":[(0,[i*10-20,0,i*15-30]),(.8,[i*10-20,0,i*15-30]),(2.2,Z)]} for i,b in enumerate(twigs)},
 {b:{"position":[(0,[0,-4,0]),(1.0,[0,-4,0]),(2.2,Z)],"scale":[(0,[1.6,1.6,1.6]),(1.0,[1.6,1.6,1.6]),(2.2,[1,1,1])]} for b in leaves_b}))
# STALK: crouched creeping 2s loop, arms on ground like a quadruped
m.animation("stalk",2,True,merge(amb(2,.6),{"root":{"position":[(0,[0,-6,0]),(.5,[0,-5,0]),(1,[0,-6,0]),(1.5,[0,-5,0]),(2,[0,-6,0])]},"hips":{"rotation":[(0,[-30,6,0]),(1,[-30,-6,0]),(2,[-30,6,0])]},"spine":{"rotation":[(0,[-20,0,0]),(2,[-20,0,0])]},"chest":{"rotation":[(0,[-15,0,0]),(2,[-15,0,0])]},"neck":{"rotation":[(0,[40,0,0]),(1,[42,0,0]),(2,[40,0,0])]},"head":{"rotation":[(0,[20,-20,0]),(1,[20,20,0]),(2,[20,-20,0])]},
 "arm_left":{"rotation":[(0,[-70,0,-10]),(.5,[-10,0,-10]),(1,[-40,0,-10]),(1.5,[-55,0,-10]),(2,[-70,0,-10])]},"fore_left":{"rotation":[(0,[10,0,0]),(.5,[-40,0,0]),(1,[15,0,0]),(2,[10,0,0])]},"hand_left":{"rotation":[(0,[60,0,0]),(.5,[10,0,0]),(1,[55,0,0]),(2,[60,0,0])]},
 "arm_right":{"rotation":[(0,[-40,0,10]),(.5,[-55,0,10]),(1,[-70,0,10]),(1.5,[-10,0,10]),(2,[-40,0,10])]},"fore_right":{"rotation":[(0,[15,0,0]),(1,[10,0,0]),(1.5,[-40,0,0]),(2,[15,0,0])]},"hand_right":{"rotation":[(0,[55,0,0]),(1,[60,0,0]),(1.5,[10,0,0]),(2,[55,0,0])]},
 "leg_left":{"rotation":[(0,[70,0,0]),(.5,[40,0,0]),(1,[80,0,0]),(1.5,[60,0,0]),(2,[70,0,0])]},"shin_left":{"rotation":[(0,[-90,0,0]),(.5,[-60,0,0]),(1,[-100,0,0]),(2,[-90,0,0])]},"foot_left":{"rotation":[(0,[20,0,0]),(.5,[40,0,0]),(2,[20,0,0])]},
 "leg_right":{"rotation":[(0,[80,0,0]),(.5,[60,0,0]),(1,[70,0,0]),(1.5,[40,0,0]),(2,[80,0,0])]},"shin_right":{"rotation":[(0,[-100,0,0]),(1,[-90,0,0]),(1.5,[-60,0,0]),(2,[-100,0,0])]},"foot_right":{"rotation":[(0,[20,0,0]),(1.5,[40,0,0]),(2,[20,0,0])]}}))
# GRAB: both long arms lunge forward and snatch 1.4s
m.animation("grab",1.4,False,merge({"root":{"position":[(0,Z),(.4,[0,1,2]),(.6,[0,-2,-4]),(1.0,[0,-1,-3]),(1.4,Z)]},"hips":{"rotation":[(0,Z),(.4,[8,0,0]),(.6,[-30,0,0]),(1.0,[-25,0,0]),(1.4,Z)]},"spine":{"rotation":[(0,Z),(.4,[10,0,0]),(.6,[-25,0,0]),(1.4,Z)]},"chest":{"rotation":[(0,Z),(.4,[8,0,0]),(.6,[-20,0,0]),(1.4,Z)]},"neck":{"rotation":[(0,Z),(.4,[-15,0,0]),(.6,[35,0,0]),(1.0,[30,0,0]),(1.4,Z)]},
 "jaw":{"rotation":[(0,Z),(.35,[35,0,0]),(.6,[40,0,0]),(.7,[0,0,0],L),(1.4,Z)]},
 "arm_left":{"rotation":[(0,Z),(.4,[40,0,-30]),(.6,[-110,0,-25]),(.75,[-95,0,5]),(1.0,[-90,0,5]),(1.4,Z)]},"fore_left":{"rotation":[(0,Z),(.4,[-30,0,0]),(.6,[-10,0,0]),(.75,[-45,0,0]),(1.4,Z)]},"hand_left":{"rotation":[(0,Z),(.4,[-40,0,0]),(.6,[-30,0,0]),(.75,[40,0,0]),(1.0,[40,0,0]),(1.4,Z)]},
 "arm_right":{"rotation":[(0,Z),(.4,[40,0,30]),(.6,[-110,0,25]),(.75,[-95,0,-5]),(1.0,[-90,0,-5]),(1.4,Z)]},"fore_right":{"rotation":[(0,Z),(.4,[-30,0,0]),(.6,[-10,0,0]),(.75,[-45,0,0]),(1.4,Z)]},"hand_right":{"rotation":[(0,Z),(.4,[-40,0,0]),(.6,[-30,0,0]),(.75,[40,0,0]),(1.0,[40,0,0]),(1.4,Z)]},
 "leg_left":{"rotation":[(0,Z),(.6,[-40,0,0]),(1.4,Z)]},"shin_left":{"rotation":[(0,Z),(.6,[40,0,0]),(1.4,Z)]},"leg_right":{"rotation":[(0,Z),(.6,[30,0,0]),(1.4,Z)]},"shin_right":{"rotation":[(0,Z),(.6,[10,0,0]),(1.4,Z)]}},
 {b:{"position":[(0,Z),(.6,[0,0,-6]),(1.4,Z)]} for b in leaves_b}))
# DEATH: crumbles like a rotten trunk 2.5s
m.animation("death",2.5,False,merge({"root":{"rotation":[(0,Z),(.4,[-10,0,0]),(1.4,[85,0,15]),(1.6,[80,0,14]),(2.5,[85,0,15],L)],"position":[(0,Z),(1.4,[0,-1,6]),(2.5,[0,-1,6],L)]},"hips":{"rotation":[(0,Z),(.5,[-15,0,0]),(1.4,Z),(2.5,Z,L)]},"spine":{"rotation":[(0,Z),(.5,[15,0,-10]),(1.4,[-10,0,-20]),(2.5,[-12,0,-22],L)]},
 "neck":{"rotation":[(0,Z),(.5,[-30,0,0]),(1.2,[20,30,0]),(1.6,[35,40,20]),(2.5,[38,40,22],L)]},"jaw":{"rotation":[(0,Z),(.4,[40,0,0]),(1.4,[35,0,0]),(2.5,[30,0,0],L)]},
 "arm_left":{"rotation":[(0,Z),(.5,[-60,0,-30]),(1.4,[-40,0,-70]),(2.5,[-42,0,-72],L)]},"fore_left":{"rotation":[(0,Z),(.5,[-50,0,0]),(1.6,[-20,0,0]),(2.5,[-20,0,0],L)]},"arm_right":{"rotation":[(0,Z),(.6,[-40,0,40]),(1.4,[20,0,60]),(2.5,[22,0,62],L)]},"fore_right":{"rotation":[(0,Z),(.6,[-60,0,0]),(1.6,[-30,0,0]),(2.5,[-30,0,0],L)]},
 "leg_left":{"rotation":[(0,Z),(.5,[-30,0,-10]),(1.4,[-20,0,-15]),(2.5,[-20,0,-15],L)]},"shin_left":{"rotation":[(0,Z),(.5,[60,0,0]),(1.4,[40,0,0]),(2.5,[40,0,0],L)]},"leg_right":{"rotation":[(0,Z),(.5,[-40,0,10]),(1.4,[10,0,15]),(2.5,[10,0,15],L)]},"shin_right":{"rotation":[(0,Z),(.5,[70,0,0]),(1.4,[20,0,0]),(2.5,[20,0,0],L)]}},
 {b:{"position":[(0,Z),(.6,[math.cos(i)*4,8,math.sin(i)*4]),(2.5,[math.cos(i)*14,-20,math.sin(i)*14],L)],"scale":[(0,[1,1,1],L),(2.0,[1,1,1],L),(2.5,[0,0,0],L)]} for i,b in enumerate(leaves_b)},
 {b:{"rotation":[(0,Z),(1.4,[40,0,i*20-40]),(2.5,[45,0,i*20-40],L)]} for i,b in enumerate(twigs)}))
m.save("forest/pale_one.bbmodel"); m.save_bedrock_animation("forest/pale_one.animation.json"); print("pale_one",len(m.elements),[a["name"] for a in m.animations])
