# Blockbench models pack

Open any `.bbmodel` in Blockbench (File → Open Model). Textures are embedded.
`*.png` + `*.png.mcmeta` next to a model are the same texture as a resourcepack-ready animated strip.
`*.animation.json` are the animations in Bedrock / Geckolib format.

## staffs/  (item models)
- scepter_of_darkness.bbmodel  – java_block, obsidian handle, purple orb, black claws
- loki_scepter.bbmodel         – Generic Model, gold shaft, blue Mind Stone, curved sickle blade
- skeletal_staff.bbmodel       – vertebra shaft, horned skull, rib crown with green soul crystal
- ice_staff.bbmodel            – frozen wood, big ice crystal, spike ring, floating shards
- wooden_staff.bbmodel         – gnarled druid branch, vine, leaf fork with nature gem
- dark_coral_staff.bbmodel     – dark coral, water orb; ANIMATED texture (6 frames)

## zombie/  (mob, 9 bones)
scary_zombie.bbmodel – anims: emerge, idle, walk, attack, death, scream

## stone_guardian/  (boss, 15 bones, animated texture 8 frames)
stone_guardian.bbmodel – anims: awaken, idle, walk, punch, slam, death, roar

## ghost_king/  (boss, 20 bones, animated texture 8 frames)
dark_ghost_king.bbmodel – anims: idle, fly, slash, cast, roar, death, spawn
